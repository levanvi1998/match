/*
 * Skypack CDN - mediasoup-client@3.7.6
 *
 * Learn more:
 *   📙 Package Documentation: https://www.skypack.dev/view/mediasoup-client
 *   📘 Skypack Documentation: https://www.skypack.dev/docs
 *
 * Pinned URL: (Optimized for Production)
 *   ▶️ Normal: https://cdn.skypack.dev/pin/mediasoup-client@v3.7.6-ZayQpAb2pbJnDcPtpbPm/mode=imports/optimized/mediasoup-client.js
 *   ⏩ Minified: https://cdn.skypack.dev/pin/mediasoup-client@v3.7.6-ZayQpAb2pbJnDcPtpbPm/mode=imports,min/optimized/mediasoup-client.js
 *
 */

// Browser-Optimized Imports (Don't directly import the URLs below in your application!)
export * from '/-/mediasoup-client@v3.7.6-ZayQpAb2pbJnDcPtpbPm/dist=es2019,mode=imports/optimized/mediasoup-client.js';
export {default} from '/-/mediasoup-client@v3.7.6-ZayQpAb2pbJnDcPtpbPm/dist=es2019,mode=imports/optimized/mediasoup-client.js';
