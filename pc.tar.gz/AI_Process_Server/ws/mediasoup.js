const mediasoup = require("mediasoup");

let worker;
let router;

const streams = new Map();
// streamID → { transport, producer, rtpPort }

async function init() {
  worker = await mediasoup.createWorker({
    rtcMinPort: 10000,
    rtcMaxPort: 15000,
    logLevel: 'warn'
  });
  router = await worker.createRouter({
    mediaCodecs: [{
      kind: "video",
      mimeType: "video/H264",
      clockRate: 90000,
      payloadType: 96,
      parameters: { "packetization-mode": 1 }
    }]
  });
}

async function startStream(streamID) {
  // If stream already exists, delete old one first and create new
  // This handles reconnection scenarios where C++ app restarts with new RTP ports
  if (streams.has(streamID)) {
    console.log(`[${streamID}] Stream already exists, deleting old stream for recreation...`);
    await deleteStream(streamID);
  }

  // Generate SSRC for this stream
  const ssrc = Math.floor(Math.random() * 0xEFFFFFFF) + 0x10000000; // Range: 0x10000000 - 0xFFFFFFFF

  const transport = await router.createPlainTransport({
    listenIp: {
      ip: '0.0.0.0',
      announcedIp: null
    },
    rtcpMux: false,  // Separate RTCP port
    comedia: true
  });

  const producer = await transport.produce({
    kind: "video",
    rtpParameters: {
      codecs: [{
        mimeType: "video/H264",
        payloadType: 96,
        clockRate: 90000,
        parameters: { "packetization-mode": 1 }
      }],
      encodings: [{ ssrc }]  // Use generated SSRC
    }
  });

  const rtpPort = transport.tuple.localPort;

  if (transport.rtcpTuple === null) {
    console.log(`[${streamID}] transport.rtcpTuple is null`);
  }
  const rtcpPort = transport.rtcpTuple ? transport.rtcpTuple.localPort : rtpPort + 1;
  const ip = transport.tuple.localIp;

  console.log(`[${streamID}] PlainTransport created:`);
  console.log(`   Local IP: ${ip}`);
  console.log(`   RTP Port: ${rtpPort}`);
  console.log(`   RTCP Port: ${rtcpPort}`);
  console.log(`   SSRC: 0x${ssrc.toString(16).toUpperCase()}`);

  const streamData = { transport, producer, rtpPort, rtcpPort, ssrc };
  streams.set(streamID, streamData);
  return streamData;
}

async function deleteStream(streamID) {
  const streamData = streams.get(streamID);
  if (!streamData) {
    console.log(`[${streamID}] Stream not found for deletion`);
    return false;
  }

  console.log(`[${streamID}] Deleting stream...`);

  // Close producer
  if (streamData.producer) {
    streamData.producer.close();
  }

  // Close transport
  if (streamData.transport) {
    streamData.transport.close();
  }

  // Remove from map
  streams.delete(streamID);

  console.log(`[${streamID}] Stream deleted successfully`);
  return true;
}

function getProducer(streamID) {
  return streams.get(streamID)?.producer;
}

module.exports = {
  init,
  startStream,
  deleteStream,
  getProducer,
  get router() { return router; },
  get streams() { return streams; }
};
