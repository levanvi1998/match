const uWS = require("uWebSockets.js");

const rooms = new Map();
// stream -> Set(ws)

function getRoom(stream) {
  if (!rooms.has(stream)) {
    rooms.set(stream, new Set());
  }
  return rooms.get(stream);
}

function startMetadataServer(port = 3000) {
  uWS.App().ws("/metadata", {
    open: (ws) => {
      ws.stream = null;
    },

    message: (ws, msg) => {
      const data = JSON.parse(Buffer.from(msg));

      // ===== C++ publish metadata =====
      if (data.stream && data.pts !== undefined) {
        const room = rooms.get(data.stream);
        if (!room) return;

        const payload = JSON.stringify(data);
        for (const client of room) {
          client.send(payload);
        }
        return;
      }

      // ===== Browser subscribe =====
      if (data.action === "subscribe" && data.stream) {
        if (ws.stream) {
          rooms.get(ws.stream)?.delete(ws);
        }

        ws.stream = data.stream;
        getRoom(data.stream).add(ws);

        ws.send(JSON.stringify({
          action: "subscribed",
          stream: data.stream
        }));
      }
    },

    close: (ws) => {
      if (ws.stream) {
        rooms.get(ws.stream)?.delete(ws);
      }
    }
  }).listen(port, () => {
    console.log("Metadata WS listening on", port);
  });
}

module.exports = { startMetadataServer };
