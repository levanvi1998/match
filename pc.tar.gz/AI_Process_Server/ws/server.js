const uWS = require("uWebSockets.js");
const mediasoup = require("./mediasoup");
const fs = require('fs');
const path = require('path');
const os = require('os');

// Function to get local IP address
function getLocalIp() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      // Skip internal (loopback) and non-IPv4 addresses
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1'; // fallback
}

// Load configuration from config.json
let config;
try {
  const configPath = path.join(__dirname, 'config.json');
  const configData = fs.readFileSync(configPath, 'utf8');
  config = JSON.parse(configData);
  console.log('✅ Configuration loaded from config.json');
} catch (err) {
  console.warn('⚠️  Failed to load config.json, using defaults:', err.message);
  config = {
    httpPort: 3000,
    webRtcTransport: {
      listenIps: [
        {
          ip: '0.0.0.0',
          announcedIp: getLocalIp()
        }
      ],
      enableUdp: true,
      enableTcp: true,
      preferUdp: true
    }
  };
}

// Auto-detect announcedIp if not set or set to 'auto'
if (config.webRtcTransport?.listenIps?.[0]) {
  const listenIp = config.webRtcTransport.listenIps[0];
  if (!listenIp.announcedIp || listenIp.announcedIp === 'auto') {
    listenIp.announcedIp = getLocalIp();
    console.log(`🔍 Auto-detected IP: ${listenIp.announcedIp}`);
  }
}

// State for WebRTC
const webRtcTransports = new Map(); // transportId -> Transport
const consumers = new Map(); // clientId -> Map<streamId, Consumer>

// ============ WebRTC Functions ============

// Create WebRTC Transport for browser client
async function createWebRtcTransport(clientId) {
  const transport = await mediasoup.router.createWebRtcTransport(config.webRtcTransport);

  console.log(`[Client ${clientId}] WebRTC Transport created (ID: ${transport.id})`);
  webRtcTransports.set(transport.id, transport);

  return {
    id: transport.id,
    iceParameters: transport.iceParameters,
    iceCandidates: transport.iceCandidates,
    dtlsParameters: transport.dtlsParameters
  };
}

// Create Consumer for browser to receive stream
async function createConsumer(clientId, streamId, transportId, rtpCapabilities) {
  const transport = webRtcTransports.get(transportId);
  if (!transport) {
    throw new Error('Transport not found');
  }

  const producer = mediasoup.getProducer(streamId);
  if (!producer) {
    console.log(`[DEBUG] Available streams:`, Array.from(mediasoup.streams.keys()));
    console.log(`[DEBUG] Requested stream: ${streamId}`);
    throw new Error('Stream not found');
  }

  if (!mediasoup.router.canConsume({ producerId: producer.id, rtpCapabilities })) {
    throw new Error('Cannot consume');
  }

  const consumer = await transport.consume({
    producerId: producer.id,
    rtpCapabilities,
    paused: false
  });

  console.log(`[Client ${clientId}] Consumer created for stream ${streamId} (ID: ${consumer.id})`);

  if (!consumers.has(clientId)) {
    consumers.set(clientId, new Map());
  }
  consumers.get(clientId).set(streamId, consumer);

  return {
    id: consumer.id,
    producerId: producer.id,
    kind: consumer.kind,
    rtpParameters: consumer.rtpParameters
  };
}

// ============ Server Start ============

(async () => {
  await mediasoup.init();
  console.log('✅ mediasoup ready\n');

  const app = uWS.App();

  // ============ Metadata WebSocket ============
  const metadataRooms = new Map(); // stream -> Set(ws)

  app.ws('/metadata', {
    compression: uWS.SHARED_COMPRESSOR,
    maxPayloadLength: 16 * 1024,
    idleTimeout: 120,

    open: (ws) => {
      ws.stream = null;
      const clientId = `metadata_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      ws.clientId = clientId;
      console.log(`[Metadata] Client connected: ${clientId}`);
    },

    message: (ws, message, isBinary) => {
      const data = JSON.parse(Buffer.from(message));

      // C++ publish metadata
      if (data.stream && data.pts !== undefined) {
        const room = metadataRooms.get(data.stream);
        if (!room) return;

        const payload = JSON.stringify(data);
        for (const client of room) {
          client.send(payload);
        }
        return;
      }

      // Browser subscribe
      if (data.action === "subscribe" && data.stream) {
        if (ws.stream) {
          metadataRooms.get(ws.stream)?.delete(ws);
        }

        ws.stream = data.stream;
        if (!metadataRooms.has(data.stream)) {
          metadataRooms.set(data.stream, new Set());
        }
        metadataRooms.get(data.stream).add(ws);

        ws.send(JSON.stringify({
          action: "subscribed",
          stream: data.stream
        }));
        console.log(`[Metadata] ${ws.clientId} subscribed to ${data.stream}`);
      }
    },

    close: (ws) => {
      if (ws.stream) {
        metadataRooms.get(ws.stream)?.delete(ws);
      }
      console.log(`[Metadata] Client disconnected: ${ws.clientId}`);
    }
  });

  // ============ Signaling WebSocket (WebRTC) ============
  app.ws('/signaling', {
    compression: uWS.SHARED_COMPRESSOR,
    maxPayloadLength: 16 * 1024,
    idleTimeout: 120,

    open: (ws) => {
      const clientId = `signaling_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      ws.clientId = clientId;
      console.log(`[Signaling] Client connected: ${clientId}`);

      // Send router RTP capabilities
      ws.send(JSON.stringify({
        type: 'routerCapabilities',
        data: mediasoup.router.rtpCapabilities
      }));
    },

    message: async (ws, message, isBinary) => {
      try {
        const msg = JSON.parse(Buffer.from(message).toString('utf8'));

        switch (msg.type) {
          case 'createTransport':
            const transportParams = await createWebRtcTransport(ws.clientId);
            ws.send(JSON.stringify({
              type: 'transportCreated',
              data: transportParams
            }));
            break;

          case 'connectTransport':
            const transport = webRtcTransports.get(msg.transportId);
            if (transport) {
              await transport.connect({ dtlsParameters: msg.dtlsParameters });
              ws.send(JSON.stringify({ type: 'transportConnected' }));
            }
            break;

          case 'consume':
            const consumerParams = await createConsumer(
              ws.clientId,
              msg.streamId,
              msg.transportId,
              msg.rtpCapabilities
            );
            ws.send(JSON.stringify({
              type: 'consumerCreated',
              data: consumerParams
            }));
            break;

          case 'resumeConsumer':
            const clientConsumers = consumers.get(ws.clientId);
            if (clientConsumers) {
              const consumer = Array.from(clientConsumers.values()).find(c => c.id === msg.consumerId);
              if (consumer) {
                await consumer.resume();
                ws.send(JSON.stringify({ type: 'consumerResumed' }));
              }
            }
            break;
        }
      } catch (error) {
        console.error('[Signaling] Error:', error);
        ws.send(JSON.stringify({ type: 'error', error: error.message }));
      }
    },

    close: (ws) => {
      console.log(`[Signaling] Client disconnected: ${ws.clientId}`);

      // Cleanup client consumers
      const clientConsumers = consumers.get(ws.clientId);
      if (clientConsumers) {
        clientConsumers.forEach(consumer => consumer.close());
        consumers.delete(ws.clientId);
      }
    }
  });

  // ============ HTTP API ============

  // POST /streams/:stream/start - Initialize stream
  app.post('/streams/:stream/start', async (res, req) => {
    res.onAborted(() => {
      res.aborted = true;
    });

    const stream = req.getParameter(0);
    console.log(`[HTTP] Start stream: ${stream}`);

    try {
      const streamData = await mediasoup.startStream(stream);

      const result = {
        success: true,
        stream,
        rtpPort: streamData.rtpPort,
        rtcpPort: streamData.rtcpPort,
        ssrc: streamData.ssrc,
        message: `Stream ready. Send RTP to 127.0.0.1:${streamData.rtpPort} (RTCP: ${streamData.rtcpPort}, SSRC: 0x${streamData.ssrc.toString(16).toUpperCase()})`
      };

      if (!res.aborted) {
        res.cork(() => {
          res.writeStatus('200 OK');
          res.writeHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(result));
        });
      }
    } catch (error) {
      console.error(`[HTTP] Error starting stream ${stream}:`, error);
      if (!res.aborted) {
        res.cork(() => {
          res.writeStatus('500 Internal Server Error');
          res.writeHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: error.message }));
        });
      }
    }
  });

  // GET /streams - List active streams
  app.get('/streams', (res, req) => {
    res.onAborted(() => {
      res.aborted = true;
    });

    try {
      const streamsList = Array.from(mediasoup.streams.keys()).map(streamId => {
        const streamData = mediasoup.streams.get(streamId);
        return {
          streamId,
          rtpPort: streamData.rtpPort,
          rtcpPort: streamData.rtcpPort,
          ssrc: streamData.ssrc,
          producerId: streamData.producer.id
        };
      });

      if (!res.aborted) {
        res.cork(() => {
          res.writeStatus('200 OK');
          res.writeHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ streams: streamsList }));
        });
      }
    } catch (error) {
      if (!res.aborted) {
        res.cork(() => {
          res.writeStatus('500 Internal Server Error');
          res.end(JSON.stringify({ error: error.message }));
        });
      }
    }
  });

  // DELETE /streams/:stream - Delete stream
  app.del('/streams/:stream', async (res, req) => {
    res.onAborted(() => {
      res.aborted = true;
    });

    const stream = req.getParameter(0);
    console.log(`[HTTP] Delete stream: ${stream}`);

    try {
      const success = await mediasoup.deleteStream(stream);

      if (!res.aborted) {
        res.cork(() => {
          if (success) {
            res.writeStatus('200 OK');
            res.writeHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({
              success: true,
              stream,
              message: `Stream ${stream} deleted successfully`
            }));
          } else {
            res.writeStatus('404 Not Found');
            res.writeHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({
              success: false,
              error: 'Stream not found'
            }));
          }
        });
      }
    } catch (error) {
      console.error(`[HTTP] Error deleting stream ${stream}:`, error);
      if (!res.aborted) {
        res.cork(() => {
          res.writeStatus('500 Internal Server Error');
          res.writeHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: error.message }));
        });
      }
    }
  });

  // Static file serving
  const fs = require('fs');
  const path = require('path');

  const mimeTypes = {
    '.html': 'text/html',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.svg': 'image/svg+xml'
  };

  app.get('/*', (res, req) => {
    res.onAborted(() => {
      res.aborted = true;
    });

    let filePath = req.getUrl();
    if (filePath === '/') {
      filePath = '/index.html';
    }

    const fullPath = path.join(__dirname, 'public', filePath);
    const ext = path.extname(fullPath);
    const contentType = mimeTypes[ext] || 'application/octet-stream';

    try {
      const data = fs.readFileSync(fullPath);
      if (!res.aborted) {
        res.cork(() => {
          res.writeStatus('200 OK');
          res.writeHeader('Content-Type', contentType);
          res.end(data);
        });
      }
    } catch (err) {
      if (!res.aborted) {
        res.cork(() => {
          res.writeStatus('404 Not Found');
          res.end('Not Found');
        });
      }
    }
  });

  app.listen(config.httpPort, (token) => {
    if (token) {
      console.log(`🌐 HTTP Server listening on port ${config.httpPort}`);
      console.log(`   http://localhost:${config.httpPort}`);
      console.log(`📡 WebSocket servers:`);
      console.log(`   Metadata: ws://localhost:${config.httpPort}/metadata`);
      console.log(`   Signaling: ws://localhost:${config.httpPort}/signaling`);
      console.log(`\n✨ Server ready for connections\n`);
    } else {
      console.error('Failed to start server');
      process.exit(1);
    }
  });
})();
