# AI Stream Engine

Hệ thống xử lý video stream real-time với AI detection sử dụng NVIDIA DeepStream, WebRTC streaming và S3 storage.

## 📋 Tổng quan

AI Stream Engine là một hệ thống hoàn chỉnh cho việc:
- Nhận video stream từ nhiều nguồn (RTSP, file, v.v.)
- Chạy AI inference (YOLO object detection) trên GPU
- Stream video qua WebRTC đến browser
- Gửi metadata detection real-time qua WebSocket
- Lưu trữ video segments và metadata lên S3/MinIO

## 🏗️ Kiến trúc hệ thống

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              AI Stream Engine                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐     ┌─────────────────────────────────────────────────┐   │
│  │ RTSP Camera  │────▶│                                                 │   │
│  └──────────────┘     │                                                 │   │
│                       │           GStreamer Pipeline                     │   │
│  ┌──────────────┐     │  ┌─────────┐   ┌─────────┐   ┌──────────────┐  │   │
│  │ Video File   │────▶│  │ Decoder │──▶│ NVInfer │──▶│ RTP Payloader│  │   │
│  └──────────────┘     │  └─────────┘   │ (YOLO)  │   └──────┬───────┘  │   │
│                       │                └────┬────┘          │          │   │
│                       │                     │               │          │   │
│                       └─────────────────────┼───────────────┼──────────┘   │
│                                             │               │              │
│                                             ▼               ▼              │
│                              ┌──────────────────┐   ┌──────────────┐       │
│                              │   AI Metadata    │   │  RTP Stream  │       │
│                              │   (Detections)   │   │  UDP Packets │       │
│                              └────────┬─────────┘   └──────┬───────┘       │
│                                       │                    │               │
│  ┌────────────────────────────────────┼────────────────────┼───────────┐   │
│  │                                    │                    │           │   │
│  │              ┌─────────────────────┼────────────────────┘           │   │
│  │              │                     │                                │   │
│  │              ▼                     ▼                                │   │
│  │     ┌────────────────┐    ┌────────────────┐                       │   │
│  │     │  mediasoup     │    │  Metadata WS   │     Node.js Server    │   │
│  │     │  (WebRTC SFU)  │    │    Server      │                       │   │
│  │     └───────┬────────┘    └───────┬────────┘                       │   │
│  │             │                     │                                 │   │
│  └─────────────┼─────────────────────┼─────────────────────────────────┘   │
│                │                     │                                     │
└────────────────┼─────────────────────┼─────────────────────────────────────┘
                 │                     │
                 ▼                     ▼
        ┌────────────────────────────────────────┐
        │              Browser Client            │
        │  ┌─────────────┐   ┌────────────────┐  │
        │  │ WebRTC Video│   │ Canvas Overlay │  │
        │  │   Player    │   │  (Bbox Draw)   │  │
        │  └─────────────┘   └────────────────┘  │
        └────────────────────────────────────────┘
```

## 📁 Cấu trúc thư mục

```
ai_engine/
├── CMakeLists.txt              # CMake build configuration
├── config.json                 # Main configuration file
├── README.md                   # This file
│
├── src/                        # C++ Source code
│   ├── main.cpp                # Entry point
│   │
│   ├── core/                   # Core components
│   │   ├── PipelineManager.*   # Manages all stream sessions
│   │   └── StreamSession.*     # Individual stream handling
│   │
│   ├── pipeline/               # GStreamer pipeline
│   │   ├── DeepStreamPipelineBuilder.*  # Pipeline construction
│   │   └── VideoRecorder.*     # Video segment recording
│   │
│   ├── ai/                     # AI/Inference
│   │   └── AIEngine.*          # DeepStream NVInfer wrapper
│   │
│   ├── aws/                    # Cloud storage
│   │   └── S3Uploader.*        # S3/MinIO upload
│   │
│   ├── http/                   # HTTP API
│   │   └── HTTPServer.*        # REST API server
│   │
│   ├── ws/                     # WebSocket client
│   │   └── MetadataWSClient.*  # Metadata WS sender
│   │
│   ├── app/                    # Application utilities
│   │   └── ConfigLoader.*      # JSON config loader
│   │
│   └── util/                   # Utilities
│       └── Logger.*            # Logging system
│
├── include/                    # Third-party headers
│   ├── httplib.h               # cpp-httplib
│   └── nlohmann/               # JSON library
│
├── ws/                         # Node.js WebRTC Server
│   ├── server.js               # Main server (HTTP + WS)
│   ├── mediasoup.js            # mediasoup wrapper
│   ├── package.json            # Node dependencies
│   └── public/                 # Web client
│       └── index.html          # Browser viewer
│
├── DeepStream-Yolo/            # YOLO parser plugin
│   └── nvdsinfer_custom_impl_Yolo/
│
└── build/                      # Build output
    ├── ai_stream               # Executable
    └── recordings/             # Video segments
```

## 🔧 Components

### 1. PipelineManager
Quản lý tất cả các stream sessions. Xử lý việc thêm/xóa/stop streams.

### 2. StreamSession
Mỗi video source có một StreamSession riêng:
- Xây dựng GStreamer pipeline
- Đăng ký với mediasoup để lấy RTP port
- Xử lý reconnection khi source bị ngắt
- Ghi video segments và upload S3

### 3. AIEngine (Singleton)
Shared inference engine cho tất cả streams:
- `nvstreammux` - Gom nhiều stream vào batch
- `nvinfer` - YOLO inference trên GPU
- Callback metadata (detections) cho mỗi stream

### 4. DeepStreamPipelineBuilder
Xây dựng GStreamer pipeline cho mỗi stream:
```
urisourcebin → parsebin → decoder → nvvideoconvert
                                          │
                    ┌─────────────────────┴────────────────────┐
                    ▼                                          ▼
              [AI Branch]                              [Streaming Branch]
           → nvstreammux                             → x264enc → rtph264pay
           → nvinfer                                        │
           → appsink                                        ▼
                                                     RTP to mediasoup
```

### 5. VideoRecorder
- Sử dụng `splitmuxsink` để chia video thành segments
- Lưu metadata JSON cho mỗi segment
- Tự động upload lên S3 khi segment hoàn thành

### 6. Node.js Server (ws/)
- **mediasoup**: WebRTC SFU - nhận RTP từ C++, stream đến browsers
- **Metadata WS**: Broadcast AI detection metadata đến browsers
- **HTTP API**: Stream management

### 7. Browser Client
- WebRTC video player
- Canvas overlay vẽ bounding boxes
- Real-time detection display

## 🔌 APIs

### HTTP REST API (C++ - Port 8211)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| POST | `/streams` | Add new stream |
| GET | `/streams` | List all streams |
| DELETE | `/streams/{id}` | Delete stream |
| POST | `/streams/{id}/stop` | Stop stream |
| POST | `/streams/{id}/record/start` | Start recording |
| POST | `/streams/{id}/record/stop` | Stop recording |

### HTTP REST API (Node.js - Port 3000)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/streams/{id}/start` | Register stream with mediasoup |
| GET | `/streams` | List active streams |
| DELETE | `/streams/{id}` | Delete stream from mediasoup |

### WebSocket APIs (Port 3000)

**Signaling WS** (`/signaling`):
- WebRTC negotiation với mediasoup
- Messages: `routerCapabilities`, `createTransport`, `consume`, etc.

**Metadata WS** (`/metadata`):
- Subscribe: `{ "action": "subscribe", "stream": "stream1" }`
- Receive: `{ "stream": "stream1", "pts": 123, "detections": [...] }`

## 📊 Data Flow

### 1. Video Flow
```
Camera/File → GStreamer → H264 Encode → RTP → mediasoup → WebRTC → Browser
```

### 2. AI Metadata Flow
```
GStreamer → NVInfer → Detection Callback → WebSocket → Browser
                                              ↓
                                    Canvas Overlay (bbox)
```

### 3. Recording Flow
```
GStreamer → splitmuxsink → .mp4 files → S3Uploader → S3/MinIO
                              ↓
                     .json metadata files
```

## ⚙️ Configuration

### config.json
```json
{
  "inferConfigPath": "/path/to/yolo_config.txt",
  "maxStreams": 4,
  
  "enableS3": true,
  "s3Bucket": "streams-data",
  "s3Region": "ap-southeast-2",
  "s3Endpoint": "192.168.31.120:9000",
  
  "httpPort": 8211,
  "metadataWSUrl": "ws://127.0.0.1:3000/metadata",
  "mediasoupServerUrl": "http://127.0.0.1:3000",
  
  "outputDir": "/path/to/recordings",
  "segmentDurationSec": 10,
  
  "logLevel": "info"
}
```

## 🚀 Build & Run

### Prerequisites
- NVIDIA GPU with CUDA
- NVIDIA DeepStream SDK 7.0+
- GStreamer 1.20+
- CMake 3.16+
- Node.js 18+

### Build C++
```bash
cd ai_engine
mkdir build && cd build
cmake ..
make -j$(nproc)
```

### Run Node.js Server
```bash
cd ai_engine/ws
npm install
npm start
```

### Run AI Engine
```bash
cd ai_engine/build
./ai_stream
```

### Add Stream
```bash
curl -X POST http://localhost:8211/streams \
  -H "Content-Type: application/json" \
  -d '{"id": "cam1", "uri": "rtsp://camera-ip/stream"}'
```

### View in Browser
Open: `http://localhost:3000`

## 📝 Metadata Format

```json
{
  "stream": "cam1",
  "ts_ms": 1703232000000,
  "pts": 123456789,
  "frame_width": 640,
  "frame_height": 640,
  "count": 2,
  "detections": [
    {
      "class": "Person",
      "class_id": 0,
      "confidence": 0.92,
      "bbox": {
        "x": 100,
        "y": 150,
        "width": 80,
        "height": 200
      }
    }
  ]
}
```

## 🔄 Reconnection Logic

1. Source ngắt kết nối → StreamSession detect via bus message
2. Destroy pipeline cũ
3. Đợi `reconnectIntervalMs` (default 5s)
4. Re-register với mediasoup (lấy port mới)
5. Build pipeline mới
6. Browser tự động reconnect khi nhận producer mới

## 📦 Dependencies

### C++
- GStreamer 1.20+
- NVIDIA DeepStream 7.0+
- AWS SDK for C++
- cpp-httplib
- nlohmann/json
- websocketpp

### Node.js
- mediasoup
- uWebSockets.js
- express

## 📄 License

Private - Internal Use Only
