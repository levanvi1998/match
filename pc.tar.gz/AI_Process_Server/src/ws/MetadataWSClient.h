#pragma once
#include <string>
#include <atomic>
#include <thread>
#include <mutex>
#include <queue>
#include <functional>
#include <websocketpp/config/asio_no_tls_client.hpp>
#include <websocketpp/client.hpp>

typedef websocketpp::client<websocketpp::config::asio_client> WsClient;
typedef websocketpp::connection_hdl ConnectionHdl;

class MetadataWSClient {
public:
    using ReconnectCallback = std::function<void()>; // Called when successfully reconnected

    MetadataWSClient(const std::string& uri);
    ~MetadataWSClient();

    bool connect();
    void disconnect();
    bool isConnected() const { return connected_; }

    // Send metadata JSON string
    void send(const std::string& metadata);

    // Set callback for reconnection events
    void setReconnectCallback(ReconnectCallback cb) { reconnect_cb_ = cb; }

private:
    void run();
    void onOpen(ConnectionHdl hdl);
    void onClose(ConnectionHdl hdl);
    void onFail(ConnectionHdl hdl);
    void onMessage(ConnectionHdl hdl, WsClient::message_ptr msg);

    std::string uri_;
    WsClient client_;
    ConnectionHdl connection_;
    std::atomic<bool> connected_{false};
    std::atomic<bool> running_{false};
    std::atomic<bool> was_connected_{false}; // Track if we were connected before
    std::thread thread_;

    std::mutex queue_mutex_;
    std::queue<std::string> send_queue_;

    ReconnectCallback reconnect_cb_;
};
