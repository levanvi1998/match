#include "MetadataWSClient.h"
#include "util/Logger.h"
#include <iostream>

using websocketpp::lib::placeholders::_1;
using websocketpp::lib::placeholders::_2;
using websocketpp::lib::bind;

MetadataWSClient::MetadataWSClient(const std::string& uri)
    : uri_(uri) {
    client_.init_asio();
    client_.set_access_channels(websocketpp::log::alevel::none);
    client_.set_error_channels(websocketpp::log::elevel::none);

    client_.set_open_handler(bind(&MetadataWSClient::onOpen, this, _1));
    client_.set_close_handler(bind(&MetadataWSClient::onClose, this, _1));
    client_.set_fail_handler(bind(&MetadataWSClient::onFail, this, _1));
    client_.set_message_handler(bind(&MetadataWSClient::onMessage, this, _1, _2));
}

MetadataWSClient::~MetadataWSClient() {
    disconnect();
}

bool MetadataWSClient::connect() {
    if (running_) return true;

    running_ = true;
    thread_ = std::thread(&MetadataWSClient::run, this);

    // Wait for connection (max 5 seconds)
    int retries = 50;
    while (!connected_ && running_ && retries-- > 0) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    return connected_;
}

void MetadataWSClient::disconnect() {
    if (!running_) return;

    running_ = false;

    try {
        if (connected_) {
            client_.close(connection_, websocketpp::close::status::normal, "Client disconnecting");
        }
        client_.stop();
    } catch (std::exception& e) {
        LOG_ERROR("MetadataWS", "Disconnect error: %s", e.what());
    }

    if (thread_.joinable()) {
        thread_.join();
    }

    connected_ = false;
}

void MetadataWSClient::send(const std::string& metadata) {
    if (!connected_) {
        // Queue for later when reconnected
        std::lock_guard<std::mutex> lock(queue_mutex_);
        send_queue_.push(metadata);
        if (send_queue_.size() > 100) { // Keep only last 100
            send_queue_.pop();
        }
        return;
    }

    try {
        client_.send(connection_, metadata, websocketpp::frame::opcode::text);
    } catch (std::exception& e) {
        LOG_ERROR("MetadataWS", "Send error: %s", e.what());
    }
}

void MetadataWSClient::run() {
    while (running_) {
        try {
            websocketpp::lib::error_code ec;
            WsClient::connection_ptr con = client_.get_connection(uri_, ec);

            if (ec) {
                LOG_ERROR("MetadataWS", "Connection error: %s", ec.message().c_str());
                std::this_thread::sleep_for(std::chrono::seconds(5));
                continue;
            }

            connection_ = con->get_handle();
            client_.connect(con);
            client_.run();
            client_.reset();

        } catch (std::exception& e) {
            LOG_ERROR("MetadataWS", "Run error: %s", e.what());
        }

        connected_ = false;

        if (running_) {
            LOG_INFO("MetadataWS", "Reconnecting in 5 seconds");
            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    }
}

void MetadataWSClient::onOpen(ConnectionHdl hdl) {
    bool was_disconnected = !connected_.load();
    bool had_previous_connection = was_connected_.load();

    connected_ = true;
    was_connected_ = true;
    LOG_INFO("MetadataWS", "Connected to %s", uri_.c_str());

    // Send queued messages
    std::lock_guard<std::mutex> lock(queue_mutex_);
    while (!send_queue_.empty()) {
        try {
            client_.send(hdl, send_queue_.front(), websocketpp::frame::opcode::text);
            send_queue_.pop();
        } catch (std::exception& e) {
            LOG_ERROR("MetadataWS", "Queue send error: %s", e.what());
            break;
        }
    }

    // Trigger reconnect callback if this is a reconnection (not first connection)
    if (was_disconnected && had_previous_connection && reconnect_cb_) {
        LOG_INFO("MetadataWS", "Reconnected - triggering callback");
        reconnect_cb_();
    }
}

void MetadataWSClient::onClose(ConnectionHdl hdl) {
    connected_ = false;
    LOG_INFO("MetadataWS", "Connection closed");
}

void MetadataWSClient::onFail(ConnectionHdl hdl) {
    connected_ = false;
    LOG_WARN("MetadataWS", "Connection failed");
}

void MetadataWSClient::onMessage(ConnectionHdl hdl, WsClient::message_ptr msg) {
    // Server might send acknowledgments or control messages
    LOG_DEBUG("MetadataWS", "Received: %s", msg->get_payload().c_str());
}
