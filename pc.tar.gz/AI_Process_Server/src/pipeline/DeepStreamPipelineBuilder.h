/**
 * DeepStreamPipelineBuilder - Creates stream pipelines for DeepStream inference
 *
 * Features:
 * - Supports RTMP, RTSP, file, and other URI sources
 * - Shared encoder for RTP + Recording (optimized resource usage)
 * - Dynamic pad handling for various media types
 */

#pragma once
#include <gst/gst.h>
#include <string>

class VideoRecorder;

// Forward declaration for internal use
namespace
{
    struct StreamParams;
}

class DeepStreamPipelineBuilder
{
public:
    /**
     * Build a stream pipeline that connects to DeepStream AIEngine
     * @param main_pipeline The main GStreamer pipeline containing DeepStream elements
     * @param stream_id Unique identifier for this stream
     * @param uri RTMP/RTSP/file URI to stream from
     * @param rtp_host RTP destination host
     * @param rtp_port RTP destination port
     * @param rtcp_port RTCP destination port
     * @param ssrc RTP SSRC value
     * @param output_dir Directory for recording output files
     * @param recorder VideoRecorder instance for recording (can be nullptr)
     * @return The stream bin, or nullptr on failure
     */
    static GstElement *build(GstElement *main_pipeline,
                             const std::string &stream_id,
                             const std::string &uri,
                             const std::string &rtp_host,
                             int rtp_port,
                             int rtcp_port,
                             unsigned int ssrc,
                             const std::string &output_dir,
                             VideoRecorder *recorder);

private:
    // Stream type detection
    enum class StreamType
    {
        RTMP,
        RTSP,
        FILE,
        OTHER
    };
    static StreamType detectStreamType(const std::string &uri);

    // Source builders
    static void buildRTSPSource(GstElement *stream_bin, const std::string &stream_id, const std::string &uri);
    static void buildRTMPSource(GstElement *stream_bin, const std::string &stream_id, const std::string &uri);
    static void buildGenericSource(GstElement *stream_bin, const std::string &stream_id, const std::string &uri);

    // Callbacks for dynamic pad linking
    static void onUriDecodePadAdded(GstElement *src, GstPad *pad, gpointer user_data);
    static void onSourcePadAdded(GstElement *src, GstPad *pad, gpointer user_data);
    static void onDemuxPadAdded(GstElement *demux, GstPad *pad, gpointer user_data);
    static void onCapsChanged(GstPad *pad, GParamSpec *pspec, gpointer user_data);

    // Video branch builders
    static void buildVideoBranch(GstElement *stream_bin, const std::string &stream_id, GstPad *src_pad, bool is_h264);
    static void buildVideoBranchRaw(GstElement *stream_bin, const std::string &stream_id, GstPad *src_pad);

    // Branch creators for encoded video
    static void createAIBranch(GstElement *stream_bin, const std::string &stream_id, GstElement *tee, bool is_h264);
    static void createRTPBranch(GstElement *stream_bin, const std::string &stream_id, GstElement *tee, bool is_h264, const struct StreamParams &params);
    static void createRecordBranch(GstElement *stream_bin, const std::string &stream_id, GstElement *tee);

    // Branch creators for RAW video (with shared encoder)
    static void createAIBranchRaw(GstElement *stream_bin, const std::string &stream_id, GstElement *tee);
    static void createSharedEncoderBranch(GstElement *stream_bin, const std::string &stream_id, GstElement *tee_raw, const struct StreamParams &params);
    static void createRTPBranchFromH264(GstElement *stream_bin, const std::string &stream_id, GstElement *tee_h264, const struct StreamParams &params);
    static void createRecordBranchFromH264(GstElement *stream_bin, const std::string &stream_id, GstElement *tee_h264, VideoRecorder *recorder);

    // Linking helpers
    static void linkToAIEngine(GstElement *stream_bin, const std::string &stream_id, GstElement *last_elem);
    static void linkToFakesink(GstElement *bin, GstPad *pad);

    // Caps detection
    static bool isVideoCaps(GstCaps *caps);
    static bool isAudioCaps(GstCaps *caps);
    static bool isH264Caps(GstCaps *caps);
    static bool isH265Caps(GstCaps *caps);
};
