#include "VideoRecorder.h"
#include "util/Logger.h"
#include <filesystem>
#include <fstream>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <algorithm>

namespace fs = std::filesystem;

VideoRecorder::VideoRecorder(const std::string &stream_id,
                             const std::string &output_dir,
                             std::shared_ptr<S3Uploader> s3)
    : stream_id_(stream_id), output_dir_(output_dir), s3_(s3)
{
    // Create base output directory
    fs::create_directories(output_dir_);
    LOG_INFO("VideoRecorder", "[%s] Created, base output: %s", stream_id_.c_str(), output_dir_.c_str());
}

VideoRecorder::~VideoRecorder()
{
    finalizePlaylist();
    LOG_INFO("VideoRecorder", "[%s] Destroyed", stream_id_.c_str());
}

void VideoRecorder::endSession()
{
    finalizePlaylist();
}

void VideoRecorder::startNewSession()
{
    // Generate session timestamp: 2025-12-28_10-30-00
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    std::tm tm;
    localtime_r(&time_t, &tm);

    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d_%H-%M-%S");
    session_timestamp_ = oss.str();

    // Create session path: outputDir/streamID/session_timestamp/
    session_path_ = output_dir_ + "/" + stream_id_ + "/" + session_timestamp_;
    fs::create_directories(session_path_);

    // Reset segment counter
    segment_count_ = 0;
    session_finalized_ = false;  // Reset finalization flag for new session
    
    // Clear metadata buffer
    {
        std::lock_guard<std::mutex> lock(metadata_mutex_);
        metadata_buffer_.clear();
    }

    // Create playlist header
    createPlaylist();

    LOG_INFO("VideoRecorder", "[%s] New session: %s", stream_id_.c_str(), session_path_.c_str());
}

std::string VideoRecorder::getS3Key(const std::string &filename)
{
    // S3 path: streams/streamID/session_timestamp/filename
    return "streams/" + stream_id_ + "/" + session_timestamp_ + "/" + filename;
}

GstElement *VideoRecorder::createRecordBin()
{
    // Start new session for each pipeline creation
    startNewSession();

    std::string bin_name = "record_bin_" + stream_id_;
    GstElement *bin = gst_bin_new(bin_name.c_str());
    if (!bin)
    {
        LOG_ERROR("VideoRecorder", "[%s] Failed to create bin", stream_id_.c_str());
        return nullptr;
    }

    // Create elements: queue -> h264parse -> mpegtsmux -> splitmuxsink
    GstElement *queue = gst_element_factory_make("queue", ("q_rec_" + stream_id_).c_str());
    GstElement *parse = gst_element_factory_make("h264parse", ("h264parse_rec_" + stream_id_).c_str());
    GstElement *mux = gst_element_factory_make("splitmuxsink", ("splitmux_" + stream_id_).c_str());
    GstElement *tsmux = gst_element_factory_make("mpegtsmux", ("tsmux_" + stream_id_).c_str());

    if (!queue || !parse || !mux || !tsmux)
    {
        LOG_ERROR("VideoRecorder", "[%s] Failed to create recording elements", stream_id_.c_str());
        if (queue) gst_object_unref(queue);
        if (parse) gst_object_unref(parse);
        if (mux) gst_object_unref(mux);
        if (tsmux) gst_object_unref(tsmux);
        gst_object_unref(bin);
        return nullptr;
    }

    // Configure queue
    g_object_set(queue, "max-size-buffers", 200, NULL);

    // Configure splitmuxsink with mpegtsmux for .ts segments
    std::string location = session_path_ + "/segment_%05d.ts";
    g_object_set(mux,
                 "location", location.c_str(),
                 "max-size-time", (guint64)(segment_duration_sec_ * GST_SECOND),
                 "muxer", tsmux,
                 "send-keyframe-requests", TRUE,
                 NULL);

    // Add elements to bin
    gst_bin_add_many(GST_BIN(bin), queue, parse, mux, NULL);

    // Link: queue -> parse -> mux
    if (!gst_element_link_many(queue, parse, mux, NULL))
    {
        LOG_ERROR("VideoRecorder", "[%s] Failed to link recording chain", stream_id_.c_str());
        gst_object_unref(bin);
        return nullptr;
    }

    // Create ghost pad for sink
    GstPad *queue_sink = gst_element_get_static_pad(queue, "sink");
    GstPad *ghost = gst_ghost_pad_new("sink", queue_sink);
    gst_element_add_pad(bin, ghost);
    gst_object_unref(queue_sink);

    // Connect format-location-full signal for segment completion callback
    g_object_set_data(G_OBJECT(mux), "recorder", this);
    g_signal_connect(mux, "format-location-full",
                     G_CALLBACK(+[](GstElement *splitmux, guint fragment_id,
                                    GstSample *first_sample, gpointer user_data) -> gchar *
                                {
                                    auto *recorder = static_cast<VideoRecorder *>(
                                        g_object_get_data(G_OBJECT(splitmux), "recorder"));

                                    gchar *location = nullptr;
                                    g_object_get(splitmux, "location", &location, NULL);

                                    if (location && recorder)
                                    {
                                        gchar *actual_file = g_strdup_printf(location, fragment_id);

                                        // Previous segment is now complete - process it
                                        if (fragment_id > 0)
                                        {
                                            gchar *prev_file = g_strdup_printf(location, fragment_id - 1);
                                            recorder->onSegmentReady(std::string(prev_file));
                                            g_free(prev_file);
                                        }

                                        g_free(location);
                                        return actual_file;
                                    }

                                    return location;
                                }),
                     nullptr);

    LOG_INFO("VideoRecorder", "[%s] HLS record bin created", stream_id_.c_str());
    LOG_INFO("VideoRecorder", "[%s] Session: %s", stream_id_.c_str(), session_path_.c_str());
    LOG_INFO("VideoRecorder", "[%s] Segments: %s (duration: %lus)", 
             stream_id_.c_str(), location.c_str(), segment_duration_sec_);

    return bin;
}

void VideoRecorder::appendMetadata(const std::string &json)
{
    std::lock_guard<std::mutex> lock(metadata_mutex_);
    metadata_buffer_.push_back(json);
}

void VideoRecorder::saveMetadata(const std::string &video_path)
{
    std::vector<std::string> metadata_copy;
    {
        std::lock_guard<std::mutex> lock(metadata_mutex_);
        metadata_copy = std::move(metadata_buffer_);
        metadata_buffer_.clear();
    }

    if (metadata_copy.empty())
    {
        LOG_INFO("VideoRecorder", "[%s] No metadata for segment", stream_id_.c_str());
        return;
    }

    // Generate metadata filename (same as video but .json)
    fs::path video_file(video_path);
    std::string metadata_path = video_file.parent_path().string() + "/" +
                                video_file.stem().string() + ".json";

    std::ofstream file(metadata_path);
    if (!file.is_open())
    {
        LOG_ERROR("VideoRecorder", "[%s] Cannot create metadata file: %s",
                  stream_id_.c_str(), metadata_path.c_str());
        return;
    }

    file << "[\n";
    for (size_t i = 0; i < metadata_copy.size(); ++i)
    {
        file << "  " << metadata_copy[i];
        if (i < metadata_copy.size() - 1)
            file << ",";
        file << "\n";
    }
    file << "]\n";
    file.close();

    LOG_INFO("VideoRecorder", "[%s] Saved metadata: %s (%zu items)",
             stream_id_.c_str(), metadata_path.c_str(), metadata_copy.size());
}

void VideoRecorder::createPlaylist()
{
    std::string playlist_path = session_path_ + "/index.m3u8";
    std::ofstream file(playlist_path);
    if (!file.is_open())
    {
        LOG_ERROR("VideoRecorder", "[%s] Cannot create playlist: %s",
                  stream_id_.c_str(), playlist_path.c_str());
        return;
    }
    
    file << "#EXTM3U\n";
    file << "#EXT-X-VERSION:3\n";
    file << "#EXT-X-TARGETDURATION:" << segment_duration_sec_ << "\n";
    file << "#EXT-X-MEDIA-SEQUENCE:0\n";
    file.close();
    
    LOG_DEBUG("VideoRecorder", "[%s] Created playlist header", stream_id_.c_str());
}

void VideoRecorder::appendToPlaylist(const std::string &segment_filename)
{
    std::string playlist_path = session_path_ + "/index.m3u8";
    std::ofstream file(playlist_path, std::ios::app);
    if (!file.is_open())
    {
        LOG_ERROR("VideoRecorder", "[%s] Cannot append to playlist: %s",
                  stream_id_.c_str(), playlist_path.c_str());
        return;
    }
    
    file << "#EXTINF:" << segment_duration_sec_ << ".0,\n";
    file << segment_filename << "\n";
    file.close();
    
    LOG_DEBUG("VideoRecorder", "[%s] Appended %s to playlist",
              stream_id_.c_str(), segment_filename.c_str());
}

void VideoRecorder::finalizePlaylist()
{
    // Prevent double finalization
    if (session_finalized_.exchange(true)) {
        LOG_DEBUG("VideoRecorder", "[%s] Session already finalized", stream_id_.c_str());
        return;
    }
    
    if (session_path_.empty())
        return;
        
    std::string playlist_path = session_path_ + "/index.m3u8";
    if (!fs::exists(playlist_path))
        return;
    
    std::ofstream file(playlist_path, std::ios::app);
    if (!file.is_open())
    {
        LOG_ERROR("VideoRecorder", "[%s] Cannot finalize playlist: %s",
                  stream_id_.c_str(), playlist_path.c_str());
        return;
    }
    
    file << "#EXT-X-ENDLIST\n";
    file.close();
    
    LOG_INFO("VideoRecorder", "[%s] Finalized playlist", stream_id_.c_str());
    
    // Upload final playlist to S3 if enabled
    if (upload_enabled_)
    {
        uploadPlaylist();
    }
}

void VideoRecorder::uploadPlaylist()
{
    if (!s3_)
        return;

    std::string playlist_path = session_path_ + "/index.m3u8";
    if (!fs::exists(playlist_path))
        return;

    // Read playlist content
    std::ifstream file(playlist_path);
    std::stringstream buffer;
    buffer << file.rdbuf();
    file.close();

    // Upload using uploadString (overwrites each time)
    std::string s3_key = getS3Key("index.m3u8");
    s3_->uploadString(buffer.str(), s3_key);
    LOG_DEBUG("VideoRecorder", "[%s] Uploaded playlist to S3", stream_id_.c_str());
}

void VideoRecorder::onSegmentReady(const std::string &local_path)
{
    LOG_INFO("VideoRecorder", "[%s] Segment ready: %s", stream_id_.c_str(), local_path.c_str());

    fs::path video_file(local_path);
    if (!fs::exists(video_file))
    {
        LOG_WARN("VideoRecorder", "[%s] Video file not found: %s", stream_id_.c_str(), local_path.c_str());
        return;
    }

    // Increment segment count
    int seg_num = segment_count_++;

    // Save metadata JSON (always save locally first)
    saveMetadata(local_path);
    
    // Append segment to m3u8 playlist
    appendToPlaylist(video_file.filename().string());
    
    std::string metadata_path = video_file.parent_path().string() + "/" +
                                video_file.stem().string() + ".json";

    // Only upload to S3 if enabled
    if (!upload_enabled_)
    {
        LOG_DEBUG("VideoRecorder", "[%s] S3 upload disabled, keeping local only", stream_id_.c_str());
        
        // Delete local files if configured to do so
        if (delete_local_if_no_upload_)
        {
            std::error_code ec;
            fs::remove(local_path, ec);
            if (ec)
            {
                LOG_WARN("VideoRecorder", "[%s] Failed to delete video: %s", stream_id_.c_str(), ec.message().c_str());
            }
            if (fs::exists(metadata_path))
            {
                fs::remove(metadata_path, ec);
                if (ec)
                {
                    LOG_WARN("VideoRecorder", "[%s] Failed to delete metadata: %s", stream_id_.c_str(), ec.message().c_str());
                }
            }
            LOG_INFO("VideoRecorder", "[%s] Deleted local files (no upload)", stream_id_.c_str());
        }
        return;
    }

    // Upload to S3
    if (s3_)
    {
        // Get filenames
        std::string segment_filename = video_file.filename().string();
        std::string metadata_filename = video_file.stem().string() + ".json";

        // Upload segment
        bool video_ok = s3_->uploadFile(local_path, getS3Key(segment_filename));
        bool metadata_ok = true;

        // Upload metadata
        if (fs::exists(metadata_path))
        {
            metadata_ok = s3_->uploadFile(metadata_path, getS3Key(metadata_filename));
        }

        // Upload updated playlist
        uploadPlaylist();

        if (video_ok)
        {
            LOG_INFO("VideoRecorder", "[%s] Uploaded segment %d to S3", stream_id_.c_str(), seg_num);
        }

        // Delete local files after successful upload
        if (remove_after_upload_ && video_ok && metadata_ok)
        {
            std::error_code ec;
            fs::remove(local_path, ec);
            if (fs::exists(metadata_path))
            {
                fs::remove(metadata_path, ec);
            }
            LOG_DEBUG("VideoRecorder", "[%s] Deleted local files after upload", stream_id_.c_str());
        }
    }
}
