#pragma once
#include <gst/gst.h>
#include <string>
#include <memory>
#include <vector>
#include <mutex>
#include <atomic>
#include "aws/S3Uploader.h"

/**
 * VideoRecorder - HLS Recording with session-based folders
 * 
 * Records video as HLS (.m3u8 + .ts segments) for web playback.
 * Each pipeline start creates a new session folder with timestamp.
 * Uses splitmuxsink for reliable segment detection.
 * 
 * Structure: outputDir/streamID/2025-12-28_10-30-00/
 *   - index.m3u8        (HLS playlist - auto generated)
 *   - segment_00000.ts  (video segment)
 *   - segment_00000.json (metadata for segment)
 *   ...
 * 
 * S3 path: bucket/streams/streamID/session_timestamp/...
 */
class VideoRecorder
{
public:
    VideoRecorder(const std::string &stream_id,
                  const std::string &output_dir,
                  std::shared_ptr<S3Uploader> s3 = nullptr);
    ~VideoRecorder();

    // Create the record bin (queue -> h264parse -> mpegtsmux -> splitmuxsink)
    // Returns a bin with ghost sink pad "sink"
    GstElement *createRecordBin();

    // Called when a segment is ready (by splitmuxsink signal)
    void onSegmentReady(const std::string &local_path);

    // Append metadata JSON for current segment
    void appendMetadata(const std::string &json);

    // Get current session info
    std::string getSessionPath() const { return session_path_; }
    std::string getSessionTimestamp() const { return session_timestamp_; }

    // Settings
    void setRemoveAfterUpload(bool remove) { remove_after_upload_ = remove; }
    void setSegmentDuration(uint64_t seconds) { segment_duration_sec_ = seconds; }
    void setDeleteLocalIfNoUpload(bool del) { delete_local_if_no_upload_ = del; }
    
    // Upload control (thread-safe)
    void setUploadEnabled(bool enabled) { upload_enabled_ = enabled; }
    bool isUploadEnabled() const { return upload_enabled_; }

    // End current recording session (add ENDLIST to playlist and upload)
    void endSession();

private:
    std::string stream_id_;
    std::string output_dir_;
    std::shared_ptr<S3Uploader> s3_;

    // Session info
    std::string session_timestamp_;  // e.g., "2025-12-28_10-30-00"
    std::string session_path_;       // e.g., "/output/streamID/2025-12-28_10-30-00"
    std::atomic<int> segment_count_{0};

    bool remove_after_upload_ = true;
    bool delete_local_if_no_upload_ = true;
    uint64_t segment_duration_sec_ = 2;
    std::atomic<bool> upload_enabled_{false};
    std::atomic<bool> session_finalized_{false};  // Prevent double finalization

    // Metadata buffer for current segment
    std::vector<std::string> metadata_buffer_;
    std::mutex metadata_mutex_;

    // Start new session (creates timestamp folder)
    void startNewSession();
    
    // Save metadata to JSON file
    void saveMetadata(const std::string &video_path);
    
    // Create initial m3u8 playlist header
    void createPlaylist();
    
    // Append new segment to m3u8 playlist
    void appendToPlaylist(const std::string &segment_filename);
    
    // Finalize playlist (add ENDLIST tag)
    void finalizePlaylist();
    
    // Upload playlist to S3
    void uploadPlaylist();
    
    // Generate S3 key for a file
    std::string getS3Key(const std::string &filename);
};
