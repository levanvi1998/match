#pragma once
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include <string>
#include <cstdint>
#include <atomic>
#include <mutex>
#include <unordered_map>
#include <nlohmann/json.hpp>

struct Detection
{
    int class_id;
    std::string class_name;
    float confidence;
    float x, y, w, h;
};

struct FrameMetadata
{
    std::string stream_id;
    uint64_t pts;
    uint64_t timestamp;
    int frame_width;   // Width of frame passed to inference (streammux output)
    int frame_height;  // Height of frame passed to inference (streammux output)
    std::vector<Detection> detections;
};

/**
 * AIEngine - Manages DeepStream inference pipeline
 * Uses NVIDIA DeepStream 8.0 with nvinfer for GPU-accelerated inference
 * 
 * NVSTREAMMUX PAD RELEASE RULES:
 * 1. NEVER release pad in pad probe callback
 * 2. NEVER release pad in streaming thread
 * 3. ALWAYS release pad in main loop (g_idle_add)
 * 4. Use BLOCK probe + EOS injection for clean release
 */
class AIEngine {
public:
    static AIEngine& instance();
    
    // Initialize the AI pipeline
    void init(GstElement* main_pipeline, uint32_t max_batch, 
              const std::string& infer_config_path);
    
    // Request a sink pad for a new stream
    GstPad* requestSinkPad(const std::string& stream_id);
    
    // Release stream resources (safe async release)
    void releaseStream(const std::string& stream_id);
    
    // Stream ID mapping
    void registerStream(int pad_index, const std::string& stream_id);
    void unregisterStream(int pad_index);
    std::string getStreamId(int pad_index);
    int getPadIndex(const std::string& stream_id);
    
    // Metadata callback (can be set by external code)
    using MetadataCallback = std::function<void(const FrameMetadata&)>;
    void setMetadataCallback(const std::string& stream_id, MetadataCallback cb);
    void removeMetadataCallback(const std::string& stream_id);
    
    // Shutdown
    void shutdown();

private:
    AIEngine() = default;
    ~AIEngine() = default;
    
    AIEngine(const AIEngine&) = delete;
    AIEngine& operator=(const AIEngine&) = delete;
    
    // GStreamer callback
    static GstFlowReturn onNewSample(GstAppSink* sink, gpointer user_data);
    void processBuffer(GstBuffer* buffer);
    
    // Pipeline elements
    GstElement* streammux_ = nullptr;
    GstElement* infer_ = nullptr;
    GstElement* sink_ = nullptr;
    
    // Streammux dimensions (for metadata)
    int mux_width_ = 640;
    int mux_height_ = 640;
    
    std::atomic<int> pad_index_{0};
    
    // Stream mapping
    std::mutex map_mutex_;
    std::unordered_map<int, std::string> pad_to_stream_;
    std::unordered_map<std::string, int> stream_to_pad_;
    std::unordered_map<std::string, GstPad*> stream_to_mux_sink_pad_;
    
    // Metadata callbacks (per stream)
    std::unordered_map<std::string, MetadataCallback> metadata_callbacks_;
    std::mutex callback_mutex_;
    
    // Class labels
    std::vector<std::string> labels_;
    void loadLabels(const std::string& labels_path);
    std::string getClassName(int class_id) const;
};
