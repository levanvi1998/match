#include "AIEngine.h"
#include "util/Logger.h"
#include <nvdsmeta.h>
#include <gstnvdsmeta.h>
#include <chrono>
#include <fstream>
#include <filesystem>

AIEngine &AIEngine::instance()
{
    static AIEngine inst;
    return inst;
}

void AIEngine::init(GstElement *main_pipeline, uint32_t max_batch,
                    const std::string &infer_config_path)
{
    LOG_INFO("AIEngine", "Initializing with DeepStream 8.0");
    
    // Create streammux
    streammux_ = gst_element_factory_make("nvstreammux", "global_mux");
    if (!streammux_) {
        LOG_ERROR("AIEngine", "Failed to create nvstreammux");
        return;
    }
    
    // Default streammux dimensions (can be made configurable)
    mux_width_ = 640;
    mux_height_ = 640;
    
    g_object_set(streammux_,
                 "batch-size", max_batch,
                 "width", mux_width_,
                 "height", mux_height_,
                 "batched-push-timeout", 40000,
                 "live-source", TRUE,
                 NULL);

    // Create nvinfer
    infer_ = gst_element_factory_make("nvinfer", "primary_infer");
    if (!infer_) {
        LOG_ERROR("AIEngine", "Failed to create nvinfer");
        return;
    }
    
    g_object_set(infer_,
                 "config-file-path", infer_config_path.c_str(),
                 NULL);

    // Create appsink
    sink_ = gst_element_factory_make("appsink", "ai_sink");
    if (!sink_) {
        LOG_ERROR("AIEngine", "Failed to create appsink");
        return;
    }
    
    g_object_set(sink_,
                 "emit-signals", TRUE,
                 "sync", FALSE,
                 "async", FALSE,
                 "max-buffers", 1,
                 "drop", TRUE,
                 NULL);

    // Set appsink callbacks
    GstAppSinkCallbacks callbacks = {
        nullptr,  // eos
        nullptr,  // new_preroll  
        onNewSample,  // new_sample
        nullptr   // padding
    };
    gst_app_sink_set_callbacks(GST_APP_SINK(sink_), &callbacks, this, nullptr);

    // Add elements to pipeline and link
    gst_bin_add_many(GST_BIN(main_pipeline), streammux_, infer_, sink_, NULL);

    if (!gst_element_link_many(streammux_, infer_, sink_, NULL)) {
        LOG_ERROR("AIEngine", "Failed to link AI pipeline");
        return;
    }
    
    // Load class labels
    std::string labels_path = std::filesystem::path(infer_config_path).parent_path().string() + "/labels.txt";
    loadLabels(labels_path);
    LOG_INFO("AIEngine", "Initialized successfully");
    LOG_INFO("AIEngine", "  Max batch: %d", max_batch);
    LOG_INFO("AIEngine", "  Config: %s", infer_config_path.c_str());
}

void AIEngine::shutdown()
{
    LOG_INFO("AIEngine", "Shutting down");
}

void AIEngine::setMetadataCallback(const std::string& stream_id, MetadataCallback cb)
{
    std::lock_guard<std::mutex> lock(callback_mutex_);
    metadata_callbacks_[stream_id] = cb;
    LOG_INFO("AIEngine", "Registered metadata callback for stream: %s", stream_id.c_str());
}

void AIEngine::removeMetadataCallback(const std::string& stream_id)
{
    std::lock_guard<std::mutex> lock(callback_mutex_);
    metadata_callbacks_.erase(stream_id);
    LOG_INFO("AIEngine", "Removed metadata callback for stream: %s", stream_id.c_str());
}

GstFlowReturn AIEngine::onNewSample(GstAppSink *sink, gpointer user_data)
{
    if (!sink || !user_data) {
        LOG_ERROR("AIEngine", "onNewSample: Invalid sink or user_data");
        return GST_FLOW_ERROR;
    }
    
    AIEngine *self = static_cast<AIEngine *>(user_data);

    GstSample *sample = gst_app_sink_pull_sample(sink);
    if (!sample)
    {
        LOG_ERROR("AIEngine", "onNewSample: Failed to pull sample from appsink");
        return GST_FLOW_ERROR;
    }

    GstBuffer *buffer = gst_sample_get_buffer(sample);
    if (!buffer) {
        gst_sample_unref(sample);
        return GST_FLOW_ERROR;
    }

    self->processBuffer(buffer);

    gst_sample_unref(sample);
    return GST_FLOW_OK;
}

void AIEngine::processBuffer(GstBuffer *buffer)
{
    NvDsBatchMeta *batch_meta = gst_buffer_get_nvds_batch_meta(buffer);
    if (!batch_meta) {
        return;
    }

    auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
                   std::chrono::system_clock::now().time_since_epoch())
                   .count();

    for (NvDsMetaList *l_frame = batch_meta->frame_meta_list;
         l_frame; l_frame = l_frame->next)
    {
        NvDsFrameMeta *frame = (NvDsFrameMeta *)l_frame->data;

        int pad_index = frame->pad_index;
        std::string stream_id = getStreamId(pad_index);
        uint64_t pts = frame->buf_pts;

        // Create metadata structure
        FrameMetadata meta;
        meta.stream_id = stream_id;
        meta.pts = pts;
        meta.timestamp = now;
        meta.frame_width = mux_width_;   // From streammux config
        meta.frame_height = mux_height_; // From streammux config

        // Process objects
        for (NvDsMetaList *l_obj = frame->obj_meta_list;
             l_obj; l_obj = l_obj->next)
        {
            NvDsObjectMeta *obj = (NvDsObjectMeta *)l_obj->data;

            Detection det;
            det.class_id = obj->class_id;
            det.class_name = getClassName(obj->class_id);
            det.confidence = obj->confidence;
            det.x = obj->rect_params.left;
            det.y = obj->rect_params.top;
            det.w = obj->rect_params.width;
            det.h = obj->rect_params.height;

            meta.detections.push_back(det);

            LOG_DEBUG("AIEngine", "[%s] Detection: class=%s conf=%.2f bbox=(%.0f,%.0f,%.0f,%.0f)",
                   stream_id.c_str(), det.class_name.c_str(), det.confidence,
                   det.x, det.y, det.w, det.h);
        }

        // Call metadata callback if set for this stream
        {
            std::lock_guard<std::mutex> lock(callback_mutex_);
            auto it = metadata_callbacks_.find(stream_id);
            if (it != metadata_callbacks_.end() && it->second) {
                it->second(meta);
            }
        }
    }
}

GstPad *AIEngine::requestSinkPad(const std::string &stream_id)
{
    int index = pad_index_.fetch_add(1);
    std::string pad_name = "sink_" + std::to_string(index);

    LOG_INFO("AIEngine", "Requesting pad: %s for stream %s", pad_name.c_str(), stream_id.c_str());

    GstPad *pad = gst_element_request_pad_simple(streammux_, pad_name.c_str());
    if (!pad)
    {
        LOG_ERROR("AIEngine", "Failed to get streammux pad %s", pad_name.c_str());
        return nullptr;
    }

    {
        std::lock_guard<std::mutex> lock(map_mutex_);
        // Hold our own reference so external code can unref safely after linking.
        stream_to_mux_sink_pad_[stream_id] = (GstPad*)gst_object_ref(pad);
    }

    registerStream(index, stream_id);
    return pad;
}

// ============================================================================
// SAFE PAD RELEASE PATTERN
// Following DeepStream community best practices:
// 1. BLOCK the pad (stop data flow immediately)
// 2. Send EOS to nvstreammux (tell it this stream is done)
// 3. Use g_idle_add to release pad in main loop
// ============================================================================

// Context for async pad release
struct PadReleaseContext {
    GstElement* streammux;
    GstPad* pad;
    std::string stream_id;
    int pad_index;
    gulong block_probe_id;
    GMutex mutex;
    GCond cond;
    gboolean done;
    gboolean cancelled;
};

// Step 3: Release pad in main loop (SAFE)
static gboolean release_pad_in_main_loop(gpointer user_data)
{
    PadReleaseContext* ctx = static_cast<PadReleaseContext*>(user_data);
    
    g_mutex_lock(&ctx->mutex);
    bool cancelled = ctx->cancelled;
    g_mutex_unlock(&ctx->mutex);
    
    if (!cancelled && ctx->streammux && GST_IS_ELEMENT(ctx->streammux) && ctx->pad) {
        // Remove block probe first
        if (ctx->block_probe_id > 0) {
            gst_pad_remove_probe(ctx->pad, ctx->block_probe_id);
            ctx->block_probe_id = 0;
        }
        
        // Release the request pad
        gst_element_release_request_pad(ctx->streammux, ctx->pad);
        gst_object_unref(ctx->pad);
        
        LOG_INFO("AIEngine", "Released pad for stream %s (in main loop)", ctx->stream_id.c_str());
    } else if (cancelled) {
        // Cancelled but still need to clean up
        if (ctx->pad) {
            if (ctx->block_probe_id > 0) {
                gst_pad_remove_probe(ctx->pad, ctx->block_probe_id);
            }
            if (ctx->streammux && GST_IS_ELEMENT(ctx->streammux)) {
                gst_element_release_request_pad(ctx->streammux, ctx->pad);
            }
            gst_object_unref(ctx->pad);
        }
        LOG_WARN("AIEngine", "Pad release completed after timeout for stream %s", ctx->stream_id.c_str());
    }
    
    // Signal completion
    g_mutex_lock(&ctx->mutex);
    ctx->done = TRUE;
    g_cond_signal(&ctx->cond);
    g_mutex_unlock(&ctx->mutex);
    
    // If cancelled, we clean up ourselves
    if (cancelled) {
        g_mutex_clear(&ctx->mutex);
        g_cond_clear(&ctx->cond);
        delete ctx;
    }
    
    return G_SOURCE_REMOVE;
}

// Step 1+2: Block probe callback - blocks data flow and triggers main loop release
static GstPadProbeReturn block_probe_callback(GstPad* pad, GstPadProbeInfo* info, gpointer user_data)
{
    PadReleaseContext* ctx = static_cast<PadReleaseContext*>(user_data);
    
    // We're now blocking! Send EOS to nvstreammux to signal end of this stream
    LOG_INFO("AIEngine", "Pad blocked for stream %s, injecting EOS", ctx->stream_id.c_str());
    
    // Send EOS event downstream to nvstreammux
    GstEvent* eos = gst_event_new_eos();
    gst_pad_send_event(pad, eos);
    
    // Schedule pad release in main loop (NEVER release in probe callback!)
    g_idle_add(release_pad_in_main_loop, ctx);
    
    // Return PASS to let EOS through, then we'll remove the probe in main loop
    return GST_PAD_PROBE_PASS;
}

void AIEngine::releaseStream(const std::string &stream_id)
{
    if (!streammux_ || !GST_IS_ELEMENT(streammux_))
    {
        LOG_WARN("AIEngine", "releaseStream: streammux is not available (stream=%s)", stream_id.c_str());
        return;
    }

    GstPad* req_pad = nullptr;
    int index = -1;
    {
        std::lock_guard<std::mutex> lock(map_mutex_);
        auto it = stream_to_mux_sink_pad_.find(stream_id);
        if (it != stream_to_mux_sink_pad_.end()) {
            req_pad = it->second;
            stream_to_mux_sink_pad_.erase(it);
        }
        auto it_idx = stream_to_pad_.find(stream_id);
        if (it_idx != stream_to_pad_.end()) {
            index = it_idx->second;
        }
    }

    if (!req_pad) {
        LOG_WARN("AIEngine", "releaseStream: request pad not found: %s", stream_id.c_str());
        if (index >= 0) {
            unregisterStream(index);
        }
        return;
    }

    LOG_INFO("AIEngine", "Releasing nvstreammux request pad for stream %s (BLOCK + EOS + main loop)", stream_id.c_str());
    
    // Create release context
    PadReleaseContext* ctx = new PadReleaseContext();
    ctx->streammux = streammux_;
    ctx->pad = req_pad;
    ctx->stream_id = stream_id;
    ctx->pad_index = index;
    ctx->block_probe_id = 0;
    g_mutex_init(&ctx->mutex);
    g_cond_init(&ctx->cond);
    ctx->done = FALSE;
    ctx->cancelled = FALSE;
    
    // Step 1: Add BLOCK probe - this will stop data flow immediately
    // When blocked, the callback will inject EOS and schedule main loop release
    ctx->block_probe_id = gst_pad_add_probe(
        req_pad,
        GST_PAD_PROBE_TYPE_BLOCK_DOWNSTREAM,
        block_probe_callback,
        ctx,
        nullptr  // Don't auto-free, we manage lifecycle
    );
    
    if (ctx->block_probe_id == 0) {
        // Block probe failed, fall back to direct main loop release
        LOG_WARN("AIEngine", "Failed to add block probe for stream %s, using direct release", stream_id.c_str());
        g_idle_add(release_pad_in_main_loop, ctx);
    }
    
    // Wait for completion with timeout
    g_mutex_lock(&ctx->mutex);
    gint64 end_time = g_get_monotonic_time() + 3 * G_TIME_SPAN_SECOND;  // 3 second timeout
    while (!ctx->done) {
        if (!g_cond_wait_until(&ctx->cond, &ctx->mutex, end_time)) {
            LOG_WARN("AIEngine", "Timeout waiting for pad release for stream %s, continuing anyway", stream_id.c_str());
            ctx->cancelled = TRUE;
            g_mutex_unlock(&ctx->mutex);
            // Don't delete ctx - callback will do it
            
            if (index >= 0) {
                unregisterStream(index);
            }
            return;
        }
    }
    g_mutex_unlock(&ctx->mutex);
    
    // Normal completion - clean up
    g_mutex_clear(&ctx->mutex);
    g_cond_clear(&ctx->cond);
    delete ctx;

    if (index >= 0) {
        unregisterStream(index);
    }
}

void AIEngine::registerStream(int pad_index, const std::string &stream_id)
{
    std::lock_guard<std::mutex> lock(map_mutex_);
    pad_to_stream_[pad_index] = stream_id;
    stream_to_pad_[stream_id] = pad_index;
    LOG_INFO("AIEngine", "Registered stream: %s with pad_index: %d", stream_id.c_str(), pad_index);
}

void AIEngine::unregisterStream(int pad_index)
{
    std::lock_guard<std::mutex> lock(map_mutex_);
    auto it = pad_to_stream_.find(pad_index);
    if (it != pad_to_stream_.end())
    {
        stream_to_pad_.erase(it->second);
        pad_to_stream_.erase(it);
    }
}

std::string AIEngine::getStreamId(int pad_index)
{
    std::lock_guard<std::mutex> lock(map_mutex_);
    auto it = pad_to_stream_.find(pad_index);
    return (it != pad_to_stream_.end()) ? it->second : "unknown";
}

int AIEngine::getPadIndex(const std::string &stream_id)
{
    std::lock_guard<std::mutex> lock(map_mutex_);
    auto it = stream_to_pad_.find(stream_id);
    return (it != stream_to_pad_.end()) ? it->second : -1;
}

void AIEngine::loadLabels(const std::string& labels_path)
{
    std::ifstream file(labels_path);
    if (!file.is_open()) {
        LOG_WARN("AIEngine", "Could not open labels file: %s", labels_path.c_str());
        return;
    }
    
    std::string line;
    while (std::getline(file, line)) {
        // Trim whitespace
        line.erase(0, line.find_first_not_of(" \t\r\n"));
        line.erase(line.find_last_not_of(" \t\r\n") + 1);
        if (!line.empty()) {
            labels_.push_back(line);
        }
    }
    
    LOG_INFO("AIEngine", "Loaded %zu class labels from %s", labels_.size(), labels_path.c_str());
}

std::string AIEngine::getClassName(int class_id) const
{
    if (class_id >= 0 && class_id < static_cast<int>(labels_.size())) {
        return labels_[class_id];
    }
    return "unknown";
}
