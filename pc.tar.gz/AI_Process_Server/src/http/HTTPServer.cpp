#include "HTTPServer.h"
#include "util/Logger.h"
#include "util/UriUtils.h"
#include <nlohmann/json.hpp>
#include <iostream>
#include <sys/socket.h>
#include <netinet/tcp.h>

using json = nlohmann::json;

HTTPServer::HTTPServer(PipelineManager &pm, int port)
    : pm_(pm), port_(port)
{
    svr_.new_task_queue = []
    { return new httplib::ThreadPool(8); };
    LOG_INFO("HTTP", "HTTP server initialized with 8-thread pool");

    setupRoutes();
}

HTTPServer::~HTTPServer()
{
    stop();
}

void HTTPServer::setupRoutes()
{
    // ==================== Stream Management ====================

    // POST /api/stream - Create new stream
    svr_.Post("/api/stream", [this](const httplib::Request &req, httplib::Response &res)
              {
        LOG_DEBUG("API", "Create stream request: %s", req.body.c_str());
        try
        {
            auto j = json::parse(req.body);
            std::string stream_id = j.value("stream_id", "");
            std::string uri = j.value("uri", "");

            if (stream_id.empty() || uri.empty())
            {
                res.status = 400;
                res.set_content(R"({"error":"stream_id and uri required"})", "application/json");
                return;
            }

            // Validate URI format and protocol/port combination
            auto validation = validateStreamUri(uri);
            if (!validation.valid)
            {
                res.status = 400;
                json err;
                err["error"] = validation.error;
                res.set_content(err.dump(), "application/json");
                LOG_WARN("API", "Invalid URI for stream %s: %s", stream_id.c_str(), validation.error.c_str());
                return;
            }

            LOG_DEBUG("API", "URI validated: protocol=%s, host=%s, port=%d, path=%s",
                     validation.info.protocol.c_str(), validation.info.host.c_str(),
                     validation.info.port, validation.info.path.c_str());

            bool ok = pm_.createStream(stream_id, uri);
            if (ok)
            {
                json response;
                response["status"] = "success";
                res.set_content(response.dump(), "application/json");
                LOG_INFO("API", "Stream %s created with URI %s", stream_id.c_str(), uri.c_str());
            }
            else
            {
                res.status = 409;
                res.set_content(R"({"error":"stream already exists"})", "application/json");
                LOG_WARN("API", "Stream %s already exists", stream_id.c_str());
            }
        } catch (std::exception& e)
        {
            res.status = 500;
            json err;
            err["error"] = e.what();
            res.set_content(err.dump(), "application/json");
            LOG_ERROR("API", "Exception creating stream: %s", e.what());
        } });

    // GET /api/stream/:stream_id - Get stream info
    svr_.Get(R"(/api/stream/([^/]+))", [this](const httplib::Request &req, httplib::Response &res)
             {
        std::string stream_id = req.matches[1];
        auto info = pm_.getStreamInfo(stream_id);

        if (info.contains("error"))
        {
            res.status = 404;
        }
        res.set_content(info.dump(), "application/json"); });

    // POST /api/stream/:stream_id/delete - Delete stream
    svr_.Post(R"(/api/stream/([^/]+)/delete)", [this](const httplib::Request &req, httplib::Response &res)
              {
        std::string stream_id = req.matches[1];
        LOG_DEBUG("API", "Delete stream id: %s", stream_id.c_str());
        bool ok = pm_.deleteStream(stream_id);

        if (ok)
        {
            json response;
            response["status"] = "success";
            res.set_content(response.dump(), "application/json");
        }
        else
        {
            res.status = 404;
            res.set_content(R"({"error":"stream not found"})", "application/json");
        } });

    // GET /api/streams - List all streams
    svr_.Get("/api/streams", [this](const httplib::Request &req, httplib::Response &res)
             {
        auto streams = pm_.listStreams();
        json response;
        response["streams"] = streams;
        response["count"] = streams.size();
        res.set_content(response.dump(), "application/json"); });

    // ==================== Stream Control ====================

    // POST /api/stream/:stream_id/start - Start stream
    svr_.Post(R"(/api/stream/([^/]+)/start)", [this](const httplib::Request &req, httplib::Response &res)
              {
        std::string stream_id = req.matches[1];
        bool ok = pm_.startStream(stream_id);

        if (ok) {
            json response;
            response["status"] = "success";
            res.set_content(response.dump(), "application/json");
        } else {
            res.status = 404;
            res.set_content(R"({"error":"stream not found"})", "application/json");
        } });

    // POST /api/stream/:stream_id/stop - Stop stream
    svr_.Post(R"(/api/stream/([^/]+)/stop)", [this](const httplib::Request &req, httplib::Response &res)
              {
        std::string stream_id = req.matches[1];
        bool ok = pm_.stopStream(stream_id);

        if (ok) {
            json response;
            response["status"] = "success";
            res.set_content(response.dump(), "application/json");
        } else {
            res.status = 404;
            res.set_content(R"({"error":"stream not found"})", "application/json");
        } });

    // ==================== Recording Control ====================

    // POST /api/stream/:stream_id/record/start - Start recording
    svr_.Post(R"(/api/stream/([^/]+)/record/start)", [this](const httplib::Request &req, httplib::Response &res)
              {
        std::string stream_id = req.matches[1];
        bool ok = pm_.startRecording(stream_id);

        if (ok) {
            json response;
            response["status"] = "success";
            res.set_content(response.dump(), "application/json");
        } else {
            res.status = 404;
            res.set_content(R"({"error":"stream not found"})", "application/json");
        } });

    // POST /api/stream/:stream_id/record/stop - Stop recording
    svr_.Post(R"(/api/stream/([^/]+)/record/stop)", [this](const httplib::Request &req, httplib::Response &res)
              {
        std::string stream_id = req.matches[1];
        bool ok = pm_.stopRecording(stream_id);

        if (ok) {
            json response;
            response["status"] = "success";
            res.set_content(response.dump(), "application/json");
        } else {
            res.status = 404;
            res.set_content(R"({"error":"stream not found"})", "application/json");
        } });

    // ==================== System Info ====================

    // GET /api/info - System info
    svr_.Get("/api/info", [this](const httplib::Request &req, httplib::Response &res)
             {
        auto streams = pm_.listStreams();
        json response;
        response["service"] = "AI Streaming Manager";
        response["version"] = "1.0.0";
        response["active_streams"] = streams.size();
        res.set_content(response.dump(), "application/json"); });
}

void HTTPServer::start()
{
    if (running_)
        return;

    // Configure timeouts to prevent hanging requests
    svr_.set_read_timeout(5, 0);              // 5 seconds read timeout
    svr_.set_write_timeout(5, 0);             // 5 seconds write timeout
    svr_.set_idle_interval(5, 0);             // 5 seconds idle check interval
    svr_.set_payload_max_length(1024 * 1024); // 1MB max payload

    // Enable keep-alive with reasonable timeout
    svr_.set_keep_alive_max_count(10); // Allow up to 10 requests per connection
    svr_.set_keep_alive_timeout(5);    // Reduce to 5 seconds to free up connections faster

    // Set socket options for better connection handling
    svr_.set_socket_options([](socket_t sock)
                            {
        int opt = 1;
        setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const void*>(&opt), sizeof(opt));

        // Set TCP keepalive
        setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, reinterpret_cast<const void*>(&opt), sizeof(opt));
        // Set TCP_NODELAY to disable Nagle's algorithm
        setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<const void*>(&opt), sizeof(opt)); });

    running_ = true;
    server_thread_ = std::thread([this]()
                                 {
        LOG_INFO("HTTP", "Server starting on port %d with 8 worker threads", port_);
        bool result = svr_.listen("0.0.0.0", port_);
        if (!result) {
            LOG_ERROR("HTTP", "Server listen() failed on port %d", port_);
        }
        LOG_INFO("HTTP", "Server stopped"); });

    LOG_INFO("HTTP", "Server started on http://0.0.0.0:%d (8 worker threads, keep-alive: 5s)", port_);
}

void HTTPServer::stop()
{
    if (!running_)
        return;

    LOG_INFO("HTTP", "Stopping server");
    svr_.stop();
    running_ = false;

    if (server_thread_.joinable())
    {
        server_thread_.join();
    }
}
