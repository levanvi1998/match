#pragma once
#include "core/PipelineManager.h"
#include "httplib.h"
#include <memory>
#include <string>

class HTTPServer {
public:
    HTTPServer(PipelineManager& pm, int port = 7879);
    ~HTTPServer();

    void start();
    void stop();
    bool isRunning() const { return running_; }

private:
    void setupRoutes();

    PipelineManager& pm_;
    int port_;
    httplib::Server svr_;
    std::thread server_thread_;
    std::atomic<bool> running_{false};
};
