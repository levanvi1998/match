#pragma once
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <mutex>
#include <thread>
#include <atomic>
#include <condition_variable>
#include "aws/S3Uploader.h"
#include "core/StreamSession.h"
#include "util/MediaMTXChecker.h"
#include <nlohmann/json.hpp>

/**
 * PipelineManager - Manages stream sessions with reconnection logic
 * 
 * Key responsibilities:
 * - Create/delete stream sessions
 * - Handle error callbacks from sessions
 * - Implement backoff reconnection strategy
 * - Centralized reconnection logic (sessions don't reconnect themselves)
 */
class PipelineManager
{
public:
    PipelineManager(GstElement* main_pipeline,
                    std::shared_ptr<S3Uploader> s3,
                    const std::string &rtpHost,
                    const std::string &metadataWSUrl,
                    const std::string &mediasoupServerUrl,
                    const std::string &mediamtxHost,
                    int mediamtxPort,
                    const std::string &outputDir,
                    bool autoRecord = false,
                    int maxReconnectAttempts = 0,  // 0 = unlimited
                    const std::vector<int>& backoffDelays = {},
                    int stallTimeoutSec = 4,
                    bool deleteLocalIfNoUpload = true);
    ~PipelineManager();

    GstElement* getMainPipeline() { return main_pipeline_; }

    // Stream lifecycle
    bool createStream(const std::string &id, const std::string &uri);
    bool deleteStream(const std::string &id);
    bool startStream(const std::string &id);
    bool stopStream(const std::string &id);

    // Recording control
    bool startRecording(const std::string &id);
    bool stopRecording(const std::string &id);

    // Stream info
    std::vector<std::string> listStreams();
    nlohmann::json getStreamInfo(const std::string &id);

    // Cleanup all streams (notify nodejs)
    void cleanupAllStreams();

private:
    // Error callback from sessions
    void onStreamError(const std::string& stream_id, StreamErrorType error_type, const std::string& error_msg);
    
    // MediaMTX path check - returns true if path exists and is ready
    bool checkMediaMTXPath(const std::string& uri);
    
    // Reconnection logic
    void scheduleReconnect(const std::string& stream_id, const std::string& uri);
    void reconnectThreadFunc(const std::string& stream_id, const std::string& uri);
    int getBackoffDelay(int attempt);  // Returns delay in seconds
    
    // Session management
    std::unordered_map<std::string, std::shared_ptr<StreamSession>> sessions_;
    std::unordered_set<std::string> active_streams_;  // Track created stream IDs
    std::mutex mux_;
    
    // Reconnection tracking
    struct ReconnectInfo {
        std::string uri;
        int attempts;
        std::atomic<bool> active;
        std::atomic<bool> cancelled;  // True if delete was called
        std::thread thread;
        
        ReconnectInfo() : attempts(0), active(false), cancelled(false) {}
    };
    std::unordered_map<std::string, std::unique_ptr<ReconnectInfo>> reconnect_info_;
    std::unordered_set<std::string> deleted_streams_;  // Track deleted streams to prevent reconnect
    std::mutex reconnect_mutex_;
    std::condition_variable reconnect_cv_;  // Signal when reconnect thread completes
    
    // Configuration
    GstElement* main_pipeline_;
    std::shared_ptr<S3Uploader> s3_;
    std::string rtpHost_;
    std::string metadataWSUrl_;
    std::string mediasoupServerUrl_;
    std::string outputDir_;
    bool autoRecord_;
    int max_reconnect_attempts_;
    int stall_timeout_sec_;
    bool delete_local_if_no_upload_;
    
    // MediaMTX checker
    std::unique_ptr<MediaMTXChecker> mediamtx_checker_;
    
    // Backoff delays in seconds (configurable)
    std::vector<int> backoff_delays_;
    
    // Default backoff delays
    static constexpr int DEFAULT_BACKOFF_DELAYS[] = {1, 2, 5, 10, 30};
    static constexpr int DEFAULT_BACKOFF_DELAY_COUNT = 5;
};
