#pragma once
#include <string>
#include <memory>
#include <atomic>
#include <thread>
#include <mutex>
#include <functional>
#include <chrono>
#include "aws/S3Uploader.h"
#include "pipeline/VideoRecorder.h"
#include "ws/MetadataWSClient.h"
#include <gst/gst.h>

/**
 * Stream state machine for robust streaming
 * 
 * State transitions:
 *   INIT -> CONNECTING -> RUNNING -> STALL -> CLEANUP -> (callback to manager)
 *                    \-> ERROR -> CLEANUP -> (callback to manager)
 * 
 * Manager decides whether to reconnect based on error type
 */
enum class StreamState
{
    INIT,       // Initial state
    CONNECTING, // Connecting to source (mediasoup, websocket, building pipeline)
    RUNNING,    // Stream is running normally
    STALL,      // No buffer received for threshold time (suspected dead)
    ERROR,      // Pipeline error detected
    CLEANUP,    // Cleaning up resources
    STOPPED     // Fully stopped
};

const char* streamStateToString(StreamState state);

/**
 * Error types for manager to decide reconnect strategy
 */
enum class StreamErrorType
{
    NONE,
    SOURCE_ERROR,     // rtspsrc, urisourcebin error - should reconnect
    STALL_TIMEOUT,    // No buffer for threshold time - should reconnect
    EOS,              // End of stream - should reconnect
    FATAL_ERROR,      // Pipeline/encoding error - should NOT reconnect
    MEDIASOUP_ERROR   // Mediasoup server error - wait and retry
};

/**
 * Callback interface for StreamSession to notify PipelineManager
 */
using StreamErrorCallback = std::function<void(const std::string& stream_id, 
                                                StreamErrorType error_type,
                                                const std::string& error_msg)>;

class StreamSession
{
public:
    StreamSession(GstElement* main_pipeline,
                  const std::string &id,
                  const std::string &uri,
                  const std::string &rtpHost,
                  const std::string &metadataWSUrl,
                  const std::string &mediasoupServerUrl,
                  const std::string &outputDir,
                  std::shared_ptr<S3Uploader> s3,
                  bool autoRecord = false,
                  int stallTimeoutSec = 4,
                  bool deleteLocalIfNoUpload = true);
    ~StreamSession();

    void start();
    void stop();
    bool isRunning() const { return state_ == StreamState::RUNNING; }
    StreamState getState() const { return state_; }

    // Recording control
    void startRecording();  // Enable S3 upload
    void stopRecording();   // Disable S3 upload
    bool isRecording() const { return recording_; }

    std::string getStreamId() const { return id_; }
    std::string getUri() const { return uri_; }

    // Error callback (called by PipelineManager)
    void setErrorCallback(StreamErrorCallback cb) { error_callback_ = cb; }

private:
    bool registerWithMediasoup();
    void notifyMediasoupStreamDeleted();
    bool checkNodejsServerHealth();
    
    // Pipeline management
    bool buildPipeline();
    void destroyPipeline();
    
    // State machine
    void setState(StreamState new_state);
    void handleError(StreamErrorType type, const std::string& msg);
    bool isValidStateTransition(StreamState from, StreamState to);
    
    // Bus message handler (pipeline owns bus watch)
    static gboolean onBusMessage(GstBus* bus, GstMessage* msg, gpointer user_data);
    
    // Watchdog: buffer probe to detect stall
    static GstPadProbeReturn onBufferProbe(GstPad* pad, GstPadProbeInfo* info, gpointer user_data);
    void updateLastBufferTime();
    void checkWatchdog();
    void watchdogThreadFunc();

    std::string id_;
    std::string uri_;
    std::string rtpHost_;
    int rtpPort_;
    int rtcpPort_;
    unsigned int ssrc_;
    std::string metadataWSUrl_;
    std::string mediasoupServerUrl_;
    std::string outputDir_;
    std::shared_ptr<S3Uploader> s3_;
    std::unique_ptr<VideoRecorder> recorder_;
    std::unique_ptr<MetadataWSClient> metadataWS_;
    bool autoRecord_;  // Auto-enable S3 upload on start

    GstElement* main_pipeline_ = nullptr;
    GstElement* pipeline_bin_ = nullptr;
    guint bus_watch_id_ = 0;
    gulong buffer_probe_id_ = 0;
    GstPad* probe_pad_ = nullptr;
    
    std::atomic<StreamState> state_{StreamState::INIT};
    std::atomic<bool> recording_{false};
    std::atomic<bool> stopping_{false};
    
    // Watchdog
    std::mutex watchdog_mutex_;
    std::chrono::steady_clock::time_point last_buffer_time_;
    std::thread watchdog_thread_;
    std::atomic<bool> watchdog_running_{false};
    
    // Timeouts (configurable)
    int stall_timeout_sec_ = 4;    // Consider stalled after N seconds no buffer
    static constexpr int CONNECT_TIMEOUT_SEC = 10; // Connection timeout
    
    // Error callback to manager
    StreamErrorCallback error_callback_;
};
