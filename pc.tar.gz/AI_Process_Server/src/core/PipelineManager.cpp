#include "PipelineManager.h"
#include "util/Logger.h"
#include "util/MediaMTXChecker.h"
#include <iostream>

constexpr int PipelineManager::DEFAULT_BACKOFF_DELAYS[];

PipelineManager::PipelineManager(GstElement* main_pipeline,
                                 std::shared_ptr<S3Uploader> s3,
                                 const std::string &rtpHost,
                                 const std::string &metadataWSUrl,
                                 const std::string &mediasoupServerUrl,
                                 const std::string &mediamtxHost,
                                 int mediamtxPort,
                                 const std::string &outputDir,
                                 bool autoRecord,
                                 int maxReconnectAttempts,
                                 const std::vector<int>& backoffDelays,
                                 int stallTimeoutSec,
                                 bool deleteLocalIfNoUpload)
    : main_pipeline_(main_pipeline), s3_(s3), rtpHost_(rtpHost),
      metadataWSUrl_(metadataWSUrl), mediasoupServerUrl_(mediasoupServerUrl), 
      outputDir_(outputDir), autoRecord_(autoRecord), max_reconnect_attempts_(maxReconnectAttempts),
      stall_timeout_sec_(stallTimeoutSec), delete_local_if_no_upload_(deleteLocalIfNoUpload)
{
    // Use provided backoff delays or defaults
    if (backoffDelays.empty()) {
        backoff_delays_.assign(DEFAULT_BACKOFF_DELAYS, DEFAULT_BACKOFF_DELAYS + DEFAULT_BACKOFF_DELAY_COUNT);
    } else {
        backoff_delays_ = backoffDelays;
    }
    
    // Initialize MediaMTX checker
    mediamtx_checker_ = std::make_unique<MediaMTXChecker>(mediamtxHost, mediamtxPort);
    
    LOG_INFO("PipelineManager", "Created (autoRecord=%s, maxReconnect=%d, stallTimeout=%ds, deleteLocal=%s, mediamtx=%s:%d)", 
             autoRecord_ ? "true" : "false", max_reconnect_attempts_, stall_timeout_sec_,
             delete_local_if_no_upload_ ? "true" : "false", mediamtxHost.c_str(), mediamtxPort);
}

PipelineManager::~PipelineManager()
{
    // Stop all reconnect threads
    {
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        for (auto& kv : reconnect_info_) {
            kv.second->active = false;
            kv.second->cancelled = true;
        }
    }
    
    // Notify all waiting threads
    reconnect_cv_.notify_all();
    
    // Wait for all reconnect threads to finish
    {
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        for (auto& kv : reconnect_info_) {
            if (kv.second->thread.joinable()) {
                kv.second->thread.join();
            }
        }
        reconnect_info_.clear();
        deleted_streams_.clear();
    }

    // First notify nodejs to delete all streams
    cleanupAllStreams();

    // Then stop all sessions
    std::lock_guard<std::mutex> lk(mux_);
    for (auto &p : sessions_)
    {
        p.second->stop();
    }
    sessions_.clear();
}

void PipelineManager::cleanupAllStreams()
{
    std::lock_guard<std::mutex> lk(mux_);
    LOG_INFO("PipelineManager", "Cleaning up %zu streams", sessions_.size());
}

// ============================================================================
// MediaMTX path check
// ============================================================================

bool PipelineManager::checkMediaMTXPath(const std::string& uri)
{
    if (!mediamtx_checker_) {
        LOG_WARN("PipelineManager", "MediaMTX checker not initialized, skipping path check");
        return true;  // Allow if no checker configured
    }
    
    std::string path = MediaMTXChecker::extractPathFromUri(uri);
    if (path.empty()) {
        LOG_WARN("PipelineManager", "Could not extract path from URI: %s", uri.c_str());
        return false;
    }
    
    LOG_DEBUG("PipelineManager", "Checking MediaMTX path: %s", path.c_str());
    auto result = mediamtx_checker_->checkPath(path);
    
    if (!result.exists) {
        LOG_WARN("PipelineManager", "MediaMTX path not found: %s (%s)", path.c_str(), result.errorMsg.c_str());
        return false;
    }
    
    if (!result.ready) {
        LOG_WARN("PipelineManager", "MediaMTX path exists but not ready: %s", path.c_str());
        return false;
    }
    
    LOG_INFO("PipelineManager", "MediaMTX path verified: %s (source=%s)", path.c_str(), result.source.c_str());
    return true;
}

// ============================================================================
// Stream lifecycle
// ============================================================================

bool PipelineManager::createStream(const std::string &id, const std::string &uri)
{
    // Check if stream already exists (in active_streams)
    {
        std::lock_guard<std::mutex> lk(mux_);
        if (active_streams_.count(id)) {
            LOG_WARN("PipelineManager", "Stream %s already exists", id.c_str());
            return false;
        }
        
        // Add to active streams immediately (track creation)
        active_streams_.insert(id);
    }
    
    // Remove from deleted_streams if re-creating
    {
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        deleted_streams_.erase(id);
    }
    
    // Check MediaMTX path availability BEFORE creating session
    if (!checkMediaMTXPath(uri)) {
        LOG_WARN("PipelineManager", "Stream %s: MediaMTX path not available, scheduling reconnect", id.c_str());
        
        // Create a placeholder session to track the stream
        std::shared_ptr<StreamSession> session;
        {
            std::lock_guard<std::mutex> lk(mux_);
            
            session = std::make_shared<StreamSession>(main_pipeline_, id, uri, rtpHost_, metadataWSUrl_, 
                                                       mediasoupServerUrl_, outputDir_, s3_, autoRecord_,
                                                       stall_timeout_sec_, delete_local_if_no_upload_);
            
            session->setErrorCallback([this](const std::string& sid, StreamErrorType type, const std::string& msg) {
                onStreamError(sid, type, msg);
            });
            
            sessions_.emplace(id, session);
        }
        
        // Schedule reconnect to retry when path becomes available
        scheduleReconnect(id, uri);
        return true;  // Return true because stream is created (pending)
    }
    
    std::shared_ptr<StreamSession> session;

    {
        std::lock_guard<std::mutex> lk(mux_);

        session = std::make_shared<StreamSession>(main_pipeline_, id, uri, rtpHost_, metadataWSUrl_, 
                                                   mediasoupServerUrl_, outputDir_, s3_, autoRecord_,
                                                   stall_timeout_sec_, delete_local_if_no_upload_);
        
        // Set error callback to handle reconnection
        session->setErrorCallback([this](const std::string& sid, StreamErrorType type, const std::string& msg) {
            onStreamError(sid, type, msg);
        });
        
        sessions_.emplace(id, session);
        LOG_INFO("PipelineManager", "Stream %s created, starting...", id.c_str());
    }

    // Start OUTSIDE of lock to avoid blocking other operations
    try
    {
        session->start();
        LOG_INFO("PipelineManager", "Stream %s started successfully", id.c_str());
    }
    catch (std::exception &e)
    {
        LOG_ERROR("PipelineManager", "Failed to start stream %s: %s", id.c_str(), e.what());
        // Remove from both maps if start failed
        {
            std::lock_guard<std::mutex> lk(mux_);
            sessions_.erase(id);
            active_streams_.erase(id);
        }
        throw;
    }

    return true;
}

bool PipelineManager::deleteStream(const std::string &id)
{
    LOG_INFO("PipelineManager", "deleteStream() called for stream: %s", id.c_str());
    
    // Check if stream exists in active_streams
    {
        std::lock_guard<std::mutex> lk(mux_);
        if (active_streams_.count(id) == 0) {
            LOG_WARN("PipelineManager", "Stream %s not found (never created or already deleted)", id.c_str());
            return false;
        }
        
        // Remove from active_streams immediately to prevent double delete
        active_streams_.erase(id);
        LOG_INFO("PipelineManager", "Stream %s removed from active_streams", id.c_str());
    }
    
    // Mark as deleted first to prevent any new reconnect attempts
    {
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        deleted_streams_.insert(id);
        
        auto it = reconnect_info_.find(id);
        if (it != reconnect_info_.end()) {
            it->second->active = false;
            it->second->cancelled = true;
            LOG_INFO("PipelineManager", "Marked reconnect as cancelled for stream: %s", id.c_str());
        }
    }
    
    // Notify any waiting reconnect threads
    reconnect_cv_.notify_all();
    
    // Wait for reconnect thread to finish if it exists
    {
        std::unique_lock<std::mutex> lock(reconnect_mutex_);
        auto it = reconnect_info_.find(id);
        if (it != reconnect_info_.end() && it->second->thread.joinable()) {
            LOG_INFO("PipelineManager", "Waiting for reconnect thread to finish for stream: %s", id.c_str());
            std::thread t = std::move(it->second->thread);
            lock.unlock();
            t.join();  // Wait outside lock to avoid deadlock
            lock.lock();
            LOG_INFO("PipelineManager", "Reconnect thread finished for stream: %s", id.c_str());
        }
        // Clean up reconnect info
        reconnect_info_.erase(id);
    }
    
    std::shared_ptr<StreamSession> session;

    {
        LOG_INFO("PipelineManager", "Acquiring lock for delete stream: %s", id.c_str());
        std::lock_guard<std::mutex> lk(mux_);
        LOG_INFO("PipelineManager", "Lock acquired, finding stream: %s", id.c_str());
        auto it = sessions_.find(id);
        if (it == sessions_.end())
        {
            // Stream might be in reconnect state (not in sessions_ yet)
            // Since we already removed from active_streams, cleanup is complete
            LOG_INFO("PipelineManager", "Stream %s not in sessions (was reconnecting), cleanup complete", id.c_str());
            return true;
        }

        // Move session out and remove from map immediately
        session = std::move(it->second);
        sessions_.erase(it);
        LOG_INFO("PipelineManager", "Stream %s removed from sessions map, stopping...", id.c_str());
    }

    // Stop synchronously to ensure cleanup completes (only if session exists)
    if (session) {
        session->stop();
        LOG_INFO("PipelineManager", "Stream %s fully stopped and cleaned up", id.c_str());
    }

    return true;
}

bool PipelineManager::startStream(const std::string &id)
{
    std::shared_ptr<StreamSession> session;

    {
        std::lock_guard<std::mutex> lk(mux_);
        auto it = sessions_.find(id);
        if (it == sessions_.end())
        {
            return false;
        }

        if (it->second->isRunning())
        {
            return true;
        }

        session = it->second;
    }

    // Start in detached thread to avoid blocking HTTP response
    std::thread([session, id]()
                {
        try {
            session->start();
            LOG_INFO("PipelineManager", "Stream %s started", id.c_str());
        } catch (std::exception& e) {
            LOG_ERROR("PipelineManager", "Failed to start stream %s: %s", id.c_str(), e.what());
        } })
        .detach();

    return true;
}

bool PipelineManager::stopStream(const std::string &id)
{
    // Cancel any pending reconnect
    {
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        auto it = reconnect_info_.find(id);
        if (it != reconnect_info_.end()) {
            it->second->active = false;
        }
    }
    
    std::shared_ptr<StreamSession> session;

    {
        std::lock_guard<std::mutex> lk(mux_);
        auto it = sessions_.find(id);
        if (it == sessions_.end())
        {
            return false;
        }

        if (!it->second->isRunning())
        {
            return true;
        }

        session = it->second;
    }

    // Stop in detached thread to avoid blocking HTTP response
    std::thread([session, id]()
                {
        session->stop();
        LOG_INFO("PipelineManager", "Stream %s stopped", id.c_str()); })
        .detach();

    return true;
}

// ============================================================================
// Recording control
// ============================================================================

bool PipelineManager::startRecording(const std::string &id)
{
    std::lock_guard<std::mutex> lk(mux_);
    auto it = sessions_.find(id);
    if (it == sessions_.end())
    {
        return false;
    }

    it->second->startRecording();
    return true;
}

bool PipelineManager::stopRecording(const std::string &id)
{
    std::shared_ptr<StreamSession> session;

    {
        std::lock_guard<std::mutex> lk(mux_);
        auto it = sessions_.find(id);
        if (it == sessions_.end())
        {
            return false;
        }
        session = it->second;
    }

    // Stop recording in detached thread to avoid blocking HTTP response
    std::thread([session, id]()
                {
        session->stopRecording();
        LOG_INFO("PipelineManager", "Recording stopped for stream %s", id.c_str()); })
        .detach();

    return true;
}

// ============================================================================
// Stream info
// ============================================================================

nlohmann::json PipelineManager::getStreamInfo(const std::string &id)
{
    std::lock_guard<std::mutex> lk(mux_);
    auto it = sessions_.find(id);
    nlohmann::json info;
    if (it == sessions_.end())
    {
        info["error"] = "stream not found";
        return info;
    }
    info["stream_id"] = id;
    info["state"] = streamStateToString(it->second->getState());
    info["running"] = it->second->isRunning();
    info["recording"] = it->second->isRecording();
    return info;
}

std::vector<std::string> PipelineManager::listStreams()
{
    std::lock_guard<std::mutex> lk(mux_);
    std::vector<std::string> out;
    // Return all active streams (including reconnecting ones)
    for (const auto& stream_id : active_streams_)
    {
        out.push_back(stream_id);
    }
    return out;
}

// ============================================================================
// Error handling and reconnection
// ============================================================================

void PipelineManager::onStreamError(const std::string& stream_id, StreamErrorType error_type, const std::string& error_msg)
{
    LOG_ERROR("PipelineManager", "[%s] Stream error: %s (type=%d)", 
              stream_id.c_str(), error_msg.c_str(), (int)error_type);
    
    // Check if stream was deleted - don't reconnect
    {
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        if (deleted_streams_.count(stream_id) > 0) {
            LOG_INFO("PipelineManager", "[%s] Stream was deleted, not reconnecting", stream_id.c_str());
            return;
        }
    }
    
    // Check if we should reconnect
    bool should_reconnect = false;
    switch (error_type) {
        case StreamErrorType::SOURCE_ERROR:
        case StreamErrorType::STALL_TIMEOUT:
        case StreamErrorType::EOS:
        case StreamErrorType::MEDIASOUP_ERROR:
            should_reconnect = true;
            break;
        case StreamErrorType::FATAL_ERROR:
        case StreamErrorType::NONE:
            should_reconnect = false;
            break;
    }
    
    if (!should_reconnect) {
        LOG_WARN("PipelineManager", "[%s] Fatal error, not reconnecting", stream_id.c_str());
        return;
    }
    
    // Get URI before modifying session
    std::string uri;
    {
        std::lock_guard<std::mutex> lk(mux_);
        auto it = sessions_.find(stream_id);
        if (it != sessions_.end()) {
            uri = it->second->getUri();
        }
    }
    
    if (!uri.empty()) {
        scheduleReconnect(stream_id, uri);
    }
}

int PipelineManager::getBackoffDelay(int attempt)
{
    if (attempt < 0) attempt = 0;
    if (backoff_delays_.empty()) {
        return 5;  // Default 5 seconds if no delays configured
    }
    if (attempt >= (int)backoff_delays_.size()) {
        return backoff_delays_.back();  // Max delay
    }
    return backoff_delays_[attempt];
}

void PipelineManager::scheduleReconnect(const std::string& stream_id, const std::string& uri)
{
    std::lock_guard<std::mutex> lock(reconnect_mutex_);
    
    // Check if stream was deleted
    if (deleted_streams_.count(stream_id) > 0) {
        LOG_INFO("PipelineManager", "[%s] Stream was deleted, not scheduling reconnect", stream_id.c_str());
        return;
    }
    
    // Create or get reconnect info
    auto& info = reconnect_info_[stream_id];
    if (!info) {
        info = std::make_unique<ReconnectInfo>();
        info->uri = uri;
    }
    
    // Check if cancelled
    if (info->cancelled) {
        LOG_INFO("PipelineManager", "[%s] Reconnect was cancelled", stream_id.c_str());
        return;
    }
    
    // Check if already reconnecting
    if (info->active) {
        LOG_DEBUG("PipelineManager", "[%s] Reconnect already in progress", stream_id.c_str());
        return;
    }
    
    // Check max attempts
    if (max_reconnect_attempts_ > 0 && info->attempts >= max_reconnect_attempts_) {
        LOG_ERROR("PipelineManager", "[%s] Max reconnect attempts (%d) reached", 
                  stream_id.c_str(), max_reconnect_attempts_);
        return;
    }
    
    info->active = true;
    info->cancelled = false;
    
    // Join previous thread if exists
    if (info->thread.joinable()) {
        info->thread.join();
    }
    
    // Start reconnect thread
    info->thread = std::thread(&PipelineManager::reconnectThreadFunc, this, stream_id, uri);
}

void PipelineManager::reconnectThreadFunc(const std::string& stream_id, const std::string& uri)
{
    // Loop for retries instead of recursive scheduleReconnect() calls
    while (true) {
        int attempt = 0;
        
        // Check if cancelled before starting
        {
            std::lock_guard<std::mutex> lock(reconnect_mutex_);
            if (deleted_streams_.count(stream_id) > 0) {
                LOG_INFO("PipelineManager", "[%s] Stream deleted, aborting reconnect", stream_id.c_str());
                return;
            }
            auto it = reconnect_info_.find(stream_id);
            if (it != reconnect_info_.end()) {
                if (it->second->cancelled) {
                    LOG_INFO("PipelineManager", "[%s] Reconnect cancelled before start", stream_id.c_str());
                    return;
                }
                attempt = it->second->attempts;
            }
        }
        
        int delay = getBackoffDelay(attempt);
        LOG_INFO("PipelineManager", "[%s] Reconnecting in %ds (attempt %d)", 
                 stream_id.c_str(), delay, attempt + 1);
        
        // Wait with backoff - use condition variable for fast cancellation
        {
            std::unique_lock<std::mutex> lock(reconnect_mutex_);
            auto pred = [this, &stream_id]() {
                auto it = reconnect_info_.find(stream_id);
                if (it == reconnect_info_.end()) return true;
                if (it->second->cancelled || !it->second->active) return true;
                if (deleted_streams_.count(stream_id) > 0) return true;
                return false;
            };
            
            if (reconnect_cv_.wait_for(lock, std::chrono::seconds(delay), pred)) {
                LOG_INFO("PipelineManager", "[%s] Reconnect cancelled during wait", stream_id.c_str());
                return;
            }
        }
        
        // Final check before reconnecting
        {
            std::lock_guard<std::mutex> lock(reconnect_mutex_);
            if (deleted_streams_.count(stream_id) > 0) {
                LOG_INFO("PipelineManager", "[%s] Stream deleted, aborting reconnect", stream_id.c_str());
                return;
            }
            auto it = reconnect_info_.find(stream_id);
            if (it != reconnect_info_.end()) {
                if (it->second->cancelled) {
                    LOG_INFO("PipelineManager", "[%s] Reconnect cancelled", stream_id.c_str());
                    return;
                }
                it->second->attempts++;
            }
        }
        
        LOG_INFO("PipelineManager", "[%s] Attempting reconnect...", stream_id.c_str());
        
        // Stop old session (get session first, then stop OUTSIDE of any manager locks)
        std::shared_ptr<StreamSession> old_session;
        {
            std::lock_guard<std::mutex> lk(mux_);
            auto it = sessions_.find(stream_id);
            if (it != sessions_.end()) {
                old_session = it->second;
                sessions_.erase(it);  // Remove from map immediately
            }
        }
        
        // Stop session outside all locks to prevent deadlock
        // (stop() can trigger callbacks that try to acquire locks)
        if (old_session) {
            old_session->stop();
        }
        
        // Final check after stopping old session
        {
            std::lock_guard<std::mutex> lock(reconnect_mutex_);
            if (deleted_streams_.count(stream_id) > 0) {
                LOG_INFO("PipelineManager", "[%s] Stream deleted after cleanup, aborting", stream_id.c_str());
                return;
            }
        }
        
        // Check MediaMTX path before creating new session
        if (!checkMediaMTXPath(uri)) {
            LOG_WARN("PipelineManager", "[%s] MediaMTX path not available, will retry", stream_id.c_str());
            
            // Check if cancelled before retrying
            bool cancelled = false;
            {
                std::lock_guard<std::mutex> lock(reconnect_mutex_);
                auto it = reconnect_info_.find(stream_id);
                if (it != reconnect_info_.end()) {
                    cancelled = it->second->cancelled;
                }
                if (deleted_streams_.count(stream_id) > 0) {
                    cancelled = true;
                }
            }
            
            if (cancelled) {
                LOG_INFO("PipelineManager", "[%s] Reconnect cancelled, exiting", stream_id.c_str());
                return;
            }
            
            // Continue loop to retry
            continue;
        }
        
        LOG_INFO("PipelineManager", "[%s] MediaMTX path available, proceeding with reconnect", stream_id.c_str());
        
        // Create new session
        std::shared_ptr<StreamSession> session;
        {
            std::lock_guard<std::mutex> lk(mux_);
            
            session = std::make_shared<StreamSession>(main_pipeline_, stream_id, uri, rtpHost_, 
                                                       metadataWSUrl_, mediasoupServerUrl_, 
                                                       outputDir_, s3_, autoRecord_, stall_timeout_sec_,
                                                       delete_local_if_no_upload_);
            
            // Set error callback
            session->setErrorCallback([this](const std::string& sid, StreamErrorType type, const std::string& msg) {
                onStreamError(sid, type, msg);
            });
            
            sessions_[stream_id] = session;
        }
        
        // Try to start
        try {
            session->start();
            LOG_INFO("PipelineManager", "[%s] Reconnect successful!", stream_id.c_str());
            
            // Reset attempt count on success
            {
                std::lock_guard<std::mutex> lock(reconnect_mutex_);
                auto it = reconnect_info_.find(stream_id);
                if (it != reconnect_info_.end()) {
                    it->second->attempts = 0;
                    it->second->active = false;
                }
            }
            
            // Success! Exit loop
            return;
        }
        catch (std::exception& e) {
            LOG_ERROR("PipelineManager", "[%s] Reconnect failed: %s", stream_id.c_str(), e.what());
            
            // Check if cancelled before retrying
            bool cancelled = false;
            {
                std::lock_guard<std::mutex> lock(reconnect_mutex_);
                auto it = reconnect_info_.find(stream_id);
                if (it != reconnect_info_.end()) {
                    cancelled = it->second->cancelled;
                }
                if (deleted_streams_.count(stream_id) > 0) {
                    cancelled = true;
                }
            }
            
            // Remove failed session
            {
                std::lock_guard<std::mutex> lk(mux_);
                sessions_.erase(stream_id);
            }
            
            if (cancelled) {
                LOG_INFO("PipelineManager", "[%s] Reconnect cancelled, exiting", stream_id.c_str());
                return;
            }
            
            // Continue loop to retry
            continue;
        }
    }
}