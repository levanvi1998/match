#include "StreamSession.h"
#include "pipeline/DeepStreamPipelineBuilder.h"
#include "pipeline/VideoRecorder.h"
#include "ai/AIEngine.h"
#include "util/Logger.h"
#include <nlohmann/json.hpp>
#include <iostream>
#include <cstring>
#include <chrono>
#include "httplib.h"

using json = nlohmann::json;

// ============================================================================
// State helpers
// ============================================================================

const char* streamStateToString(StreamState state)
{
    switch (state) {
        case StreamState::INIT:       return "INIT";
        case StreamState::CONNECTING: return "CONNECTING";
        case StreamState::RUNNING:    return "RUNNING";
        case StreamState::STALL:      return "STALL";
        case StreamState::ERROR:      return "ERROR";
        case StreamState::CLEANUP:    return "CLEANUP";
        case StreamState::STOPPED:    return "STOPPED";
        default:                      return "UNKNOWN";
    }
}

// ============================================================================
// Constructor / Destructor
// ============================================================================

StreamSession::StreamSession(GstElement* main_pipeline,
                             const std::string &id,
                             const std::string &uri,
                             const std::string &rtpHost,
                             const std::string &metadataWSUrl,
                             const std::string &mediasoupServerUrl,
                             const std::string &outputDir,
                             std::shared_ptr<S3Uploader> s3,
                             bool autoRecord,
                             int stallTimeoutSec,
                             bool deleteLocalIfNoUpload)
    : main_pipeline_(main_pipeline), id_(id), uri_(uri), rtpHost_(rtpHost), rtpPort_(0), rtcpPort_(0), ssrc_(0),
      metadataWSUrl_(metadataWSUrl), mediasoupServerUrl_(mediasoupServerUrl), outputDir_(outputDir), s3_(s3),
      autoRecord_(autoRecord), stall_timeout_sec_(stallTimeoutSec)
{
    // Create VideoRecorder for this stream
    recorder_ = std::make_unique<VideoRecorder>(id_, outputDir_, s3_);
    recorder_->setRemoveAfterUpload(true);
    recorder_->setUploadEnabled(autoRecord_);  // Set based on config
    recorder_->setDeleteLocalIfNoUpload(deleteLocalIfNoUpload);
    
    metadataWS_ = std::make_unique<MetadataWSClient>(metadataWSUrl_);
    
    LOG_INFO("StreamSession", "[%s] Created (autoRecord=%s, stallTimeout=%ds, deleteLocal=%s)", 
             id_.c_str(), autoRecord_ ? "true" : "false", stall_timeout_sec_,
             deleteLocalIfNoUpload ? "true" : "false");
}

StreamSession::~StreamSession()
{
    stop();
}

// ============================================================================
// State machine
// ============================================================================

bool StreamSession::isValidStateTransition(StreamState from, StreamState to)
{
    // Define valid state transitions
    switch (from) {
        case StreamState::INIT:
            return to == StreamState::CONNECTING || to == StreamState::CLEANUP;
        case StreamState::CONNECTING:
            return to == StreamState::RUNNING || to == StreamState::ERROR || to == StreamState::CLEANUP;
        case StreamState::RUNNING:
            return to == StreamState::STALL || to == StreamState::ERROR || to == StreamState::CLEANUP;
        case StreamState::STALL:
            return to == StreamState::RUNNING || to == StreamState::ERROR || to == StreamState::CLEANUP;
        case StreamState::ERROR:
            return to == StreamState::CLEANUP;
        case StreamState::CLEANUP:
            return to == StreamState::STOPPED;
        case StreamState::STOPPED:
            return false;  // Terminal state - no transitions allowed
        default:
            return false;
    }
}

void StreamSession::setState(StreamState new_state)
{
    StreamState old_state = state_.load();
    
    // Check for valid transition
    if (!isValidStateTransition(old_state, new_state)) {
        LOG_WARN("StreamSession", "[%s] Invalid state transition: %s -> %s (ignored)", 
                 id_.c_str(), streamStateToString(old_state), streamStateToString(new_state));
        return;
    }
    
    // Atomic compare-exchange to ensure thread safety
    if (state_.compare_exchange_strong(old_state, new_state)) {
        LOG_INFO("StreamSession", "[%s] State: %s -> %s", 
                 id_.c_str(), streamStateToString(old_state), streamStateToString(new_state));
    }
}

void StreamSession::handleError(StreamErrorType type, const std::string& msg)
{
    // Check if already stopping or stopped
    if (stopping_ || state_ == StreamState::CLEANUP || state_ == StreamState::STOPPED) {
        LOG_DEBUG("StreamSession", "[%s] Ignoring error during cleanup: %s", id_.c_str(), msg.c_str());
        return;
    }
    
    LOG_ERROR("StreamSession", "[%s] Error: %s (type=%d)", id_.c_str(), msg.c_str(), (int)type);
    
    // End recording session immediately when error occurs
    if (recorder_ && recording_) {
        recorder_->endSession();
        LOG_INFO("StreamSession", "[%s] Ended recording session due to error", id_.c_str());
    }
    
    setState(StreamState::ERROR);
    
    // Notify manager via callback (manager decides reconnect strategy)
    if (error_callback_) {
        error_callback_(id_, type, msg);
    }
}

// ============================================================================
// Mediasoup registration
// ============================================================================

bool StreamSession::registerWithMediasoup()
{
    if (mediasoupServerUrl_.empty())
    {
        rtpPort_ = 5004;  // Use default if no mediasoup
        rtcpPort_ = 5005; // RTCP is typically RTP + 1
        ssrc_ = 0x12345678; // Default SSRC
        return true;
    }

    try
    {
        // Parse URL to extract host and port
        std::string url = mediasoupServerUrl_ + "/streams/" + id_ + "/start";
        size_t protocolEnd = url.find("://");
        size_t hostStart = protocolEnd != std::string::npos ? protocolEnd + 3 : 0;
        size_t portStart = url.find(":", hostStart);
        size_t pathStart = url.find("/", hostStart);

        std::string host;
        int port = 3000; // default
        std::string path = "/streams/" + id_ + "/start";

        if (portStart != std::string::npos && portStart < pathStart)
        {
            host = url.substr(hostStart, portStart - hostStart);
            port = std::stoi(url.substr(portStart + 1, pathStart - portStart - 1));
        }
        else
        {
            host = url.substr(hostStart, pathStart - hostStart);
        }

        httplib::Client cli(host, port);
        cli.set_connection_timeout(5, 0);
        cli.set_read_timeout(5, 0);
        cli.set_write_timeout(5, 0);

        LOG_INFO("StreamSession", "[%s] Registering with mediasoup at %s:%d%s", id_.c_str(), host.c_str(), port, path.c_str());
        auto res = cli.Post(path.c_str());

        if (res && res->status == 200)
        {
            try
            {
                auto response = json::parse(res->body);
                if (response.contains("rtpPort"))
                {
                    rtpPort_ = response["rtpPort"];
                    rtcpPort_ = response.value("rtcpPort", rtpPort_ + 1);
                    ssrc_ = response.value("ssrc", 0x12345678);
                    
                    LOG_INFO("StreamSession", "[%s] Mediasoup ready - RTP:%d RTCP:%d SSRC:0x%08X",
                             id_.c_str(), rtpPort_, rtcpPort_, ssrc_);
                    return true;
                }
            }
            catch (std::exception &e)
            {
                LOG_ERROR("StreamSession", "[%s] Failed to parse mediasoup response: %s", id_.c_str(), e.what());
            }
        }
    }
    catch (std::exception &e)
    {
        LOG_ERROR("StreamSession", "[%s] Error contacting mediasoup: %s", id_.c_str(), e.what());
    }

    // Fallback if registration failed
    if (rtpPort_ == 0)
    {
        rtpPort_ = 5004;
        rtcpPort_ = 5005;
        ssrc_ = 0x12345678;
        LOG_WARN("StreamSession", "[%s] Mediasoup registration failed, using fallback ports", id_.c_str());
    }
    return false;
}

bool StreamSession::checkNodejsServerHealth()
{
    if (mediasoupServerUrl_.empty())
        return true;

    try
    {
        // Parse URL
        std::string url = mediasoupServerUrl_ + "/streams";
        size_t protocolEnd = url.find("://");
        size_t hostStart = protocolEnd != std::string::npos ? protocolEnd + 3 : 0;
        size_t portStart = url.find(":", hostStart);
        size_t pathStart = url.find("/", hostStart);

        std::string host;
        int port = 3000;

        if (portStart != std::string::npos && portStart < pathStart)
        {
            host = url.substr(hostStart, portStart - hostStart);
            port = std::stoi(url.substr(portStart + 1, pathStart - portStart - 1));
        }
        else
        {
            host = url.substr(hostStart, pathStart - hostStart);
        }

        httplib::Client cli(host, port);
        cli.set_connection_timeout(5, 0);
        auto res = cli.Get("/streams");

        return (res && (res->status == 200 || res->status == 404));
    }
    catch (...)
    {
        return false;
    }
}

void StreamSession::notifyMediasoupStreamDeleted()
{
    if (mediasoupServerUrl_.empty())
        return;

    try
    {
        std::string url = mediasoupServerUrl_ + "/streams/" + id_;
        size_t protocolEnd = url.find("://");
        size_t hostStart = protocolEnd != std::string::npos ? protocolEnd + 3 : 0;
        size_t portStart = url.find(":", hostStart);
        size_t pathStart = url.find("/", hostStart);

        std::string host;
        int port = 3000;
        std::string path = "/streams/" + id_;

        if (portStart != std::string::npos && portStart < pathStart)
        {
            host = url.substr(hostStart, portStart - hostStart);
            port = std::stoi(url.substr(portStart + 1, pathStart - portStart - 1));
        }
        else
        {
            host = url.substr(hostStart, pathStart - hostStart);
        }

        httplib::Client cli(host, port);
        cli.set_connection_timeout(2, 0);
        
        LOG_INFO("StreamSession", "[%s] Notifying mediasoup to delete stream", id_.c_str());
        auto res = cli.Delete(path.c_str());
        
        if (res && res->status == 200)
        {
            LOG_INFO("StreamSession", "[%s] Mediasoup stream deleted", id_.c_str());
        }
        else if (res)
        {
            LOG_WARN("StreamSession", "[%s] Mediasoup delete returned status %d", id_.c_str(), res->status);
        }
    }
    catch (std::exception &e)
    {
        LOG_WARN("StreamSession", "[%s] Failed to notify mediasoup: %s", id_.c_str(), e.what());
    }
}

// ============================================================================
// Start / Stop
// ============================================================================

void StreamSession::start()
{
    if (state_ == StreamState::RUNNING || state_ == StreamState::CONNECTING)
    {
        LOG_WARN("StreamSession", "[%s] Already running/connecting", id_.c_str());
        return;
    }

    LOG_INFO("StreamSession", "[%s] Starting stream: %s", id_.c_str(), uri_.c_str());
    setState(StreamState::CONNECTING);
    stopping_ = false;

    // Register with mediasoup to get RTP ports
    registerWithMediasoup();

    // Connect metadata websocket
    metadataWS_->connect();

    // Build pipeline
    if (!buildPipeline()) {
        LOG_ERROR("StreamSession", "[%s] Failed to build pipeline", id_.c_str());
        handleError(StreamErrorType::FATAL_ERROR, "Failed to build pipeline");
        return;
    }
    
    // Start watchdog thread
    watchdog_running_ = true;
    last_buffer_time_ = std::chrono::steady_clock::now();
    watchdog_thread_ = std::thread(&StreamSession::watchdogThreadFunc, this);
    
    // If autoRecord enabled, start S3 upload
    if (autoRecord_) {
        startRecording();
    }
    
    setState(StreamState::RUNNING);
    LOG_INFO("StreamSession", "[%s] Stream started successfully", id_.c_str());
}

bool StreamSession::buildPipeline()
{
    LOG_INFO("StreamSession", "[%s] Building pipeline...", id_.c_str());
    
    pipeline_bin_ = DeepStreamPipelineBuilder::build(
        main_pipeline_,
        id_,
        uri_,
        rtpHost_,
        rtpPort_,
        rtcpPort_,
        ssrc_,
        outputDir_,
        recorder_.get()
    );

    if (!pipeline_bin_)
    {
        LOG_ERROR("StreamSession", "[%s] Failed to build pipeline", id_.c_str());
        return false;
    }

    LOG_INFO("StreamSession", "[%s] Pipeline built, setting up bus watch...", id_.c_str());
    
    // Setup bus watch for error handling
    GstBus* bus = gst_pipeline_get_bus(GST_PIPELINE(main_pipeline_));
    if (bus) {
        bus_watch_id_ = gst_bus_add_watch(bus, onBusMessage, this);
        gst_object_unref(bus);
    }
    
    // Sync source element state with main pipeline
    gst_element_sync_state_with_parent(pipeline_bin_);
    
    // Wire AI metadata callback to WebSocket and buffer
    AIEngine::instance().setMetadataCallback(id_, [this](const FrameMetadata& meta) {
        // Update watchdog timer on every metadata (indicates buffers flowing)
        updateLastBufferTime();
        
        // Skip empty frames
        if (meta.detections.empty()) {
            return;
        }
        
        // Format: {"stream": "video1", "ts_ms": 1234, "pts": 5678, "frame_width": 640, "frame_height": 640, "count": 2, "detections": [...]}
        nlohmann::json j;
        j["stream"] = meta.stream_id;
        j["ts_ms"] = meta.timestamp;
        j["pts"] = meta.pts;
        j["frame_width"] = meta.frame_width;
        j["frame_height"] = meta.frame_height;
        j["count"] = meta.detections.size();
        j["detections"] = nlohmann::json::array();
        
        for (const auto& det : meta.detections) {
            nlohmann::json detection;
            detection["class"] = det.class_name;
            detection["class_id"] = det.class_id;
            detection["confidence"] = det.confidence;
            detection["bbox"] = {
                {"x", static_cast<int>(det.x)},
                {"y", static_cast<int>(det.y)},
                {"width", static_cast<int>(det.w)},
                {"height", static_cast<int>(det.h)}
            };
            j["detections"].push_back(detection);
        }
        
        std::string json_str = j.dump();
        
        // Send to WebSocket (real-time)
        if (metadataWS_ && metadataWS_->isConnected()) {
            metadataWS_->send(json_str);
        }
        
        // Buffer metadata for segment file (will be flushed when video segment is ready)
        if (recorder_) {
            recorder_->appendMetadata(json_str);
        }
    });
    
    return true;
}

void StreamSession::stop()
{
    // Check if already stopping or stopped
    StreamState current = state_.load();
    if (stopping_ || current == StreamState::CLEANUP || current == StreamState::STOPPED) {
        LOG_DEBUG("StreamSession", "[%s] Already stopping/stopped (state=%s)", 
                  id_.c_str(), streamStateToString(current));
        return;
    }
    
    stopping_ = true;
    setState(StreamState::CLEANUP);

    LOG_INFO("StreamSession", "[%s] Stopping stream", id_.c_str());

    // Stop watchdog thread
    watchdog_running_ = false;
    if (watchdog_thread_.joinable()) {
        watchdog_thread_.join();
    }

    // Stop recording if active
    if (recording_)
    {
        stopRecording();
    }

    // Clear metadata callback to avoid dangling references
    AIEngine::instance().removeMetadataCallback(id_);
    
    // Disconnect metadata websocket
    if (metadataWS_)
    {
        metadataWS_->disconnect();
    }

    // Remove bus watch
    if (bus_watch_id_ > 0) {
        g_source_remove(bus_watch_id_);
        bus_watch_id_ = 0;
    }

    // Destroy pipeline
    destroyPipeline();

    // Notify mediasoup
    notifyMediasoupStreamDeleted();

    setState(StreamState::STOPPED);
    LOG_INFO("StreamSession", "[%s] Stream stopped", id_.c_str());
}

void StreamSession::destroyPipeline()
{
    if (!pipeline_bin_)
        return;

    if (!GST_IS_ELEMENT(pipeline_bin_)) {
        LOG_WARN("StreamSession", "[%s] pipeline_bin_ is not a valid GstElement", id_.c_str());
        pipeline_bin_ = nullptr;
        return;
    }

    LOG_INFO("StreamSession", "[%s] Destroying pipeline elements", id_.c_str());

    // Set state to NULL
    gst_element_set_state(pipeline_bin_, GST_STATE_NULL);

    // Wait until the per-stream bin really reaches NULL
    GstState current = GST_STATE_VOID_PENDING;
    GstState pending = GST_STATE_VOID_PENDING;
    GstStateChangeReturn scr = gst_element_get_state(pipeline_bin_, &current, &pending, 2 * GST_SECOND);
    if (scr == GST_STATE_CHANGE_ASYNC) {
        scr = gst_element_get_state(pipeline_bin_, &current, &pending, 2 * GST_SECOND);
    }
    if (current != GST_STATE_NULL) {
        LOG_WARN("StreamSession", "[%s] Stream bin state not NULL before remove (cur=%s pending=%s)",
                 id_.c_str(), gst_element_state_get_name(current), gst_element_state_get_name(pending));
    }
    
    // Remove from main pipeline
    if (main_pipeline_ && GST_IS_BIN(main_pipeline_)) {
        gst_bin_remove(GST_BIN(main_pipeline_), pipeline_bin_);
    }
    pipeline_bin_ = nullptr;

    // Release AI engine resources
    AIEngine::instance().releaseStream(id_);
}

// ============================================================================
// Recording control
// ============================================================================

void StreamSession::startRecording()
{
    if (recording_)
    {
        LOG_WARN("StreamSession", "[%s] Already recording", id_.c_str());
        return;
    }

    LOG_INFO("StreamSession", "[%s] Starting recording (enabling S3 upload)", id_.c_str());
    
    if (recorder_)
    {
        recorder_->setUploadEnabled(true);
        recording_ = true;
        LOG_INFO("StreamSession", "[%s] Recording started", id_.c_str());
    }
}

void StreamSession::stopRecording()
{
    if (!recording_)
        return;

    LOG_INFO("StreamSession", "[%s] Stopping recording (disabling S3 upload)", id_.c_str());
    
    if (recorder_)
    {
        // End session immediately - finalize playlist and upload
        recorder_->endSession();
        recorder_->setUploadEnabled(false);
        recording_ = false;
        LOG_INFO("StreamSession", "[%s] Recording stopped", id_.c_str());
    }
}

// ============================================================================
// Watchdog - detect stalled streams
// ============================================================================

void StreamSession::updateLastBufferTime()
{
    std::lock_guard<std::mutex> lock(watchdog_mutex_);
    last_buffer_time_ = std::chrono::steady_clock::now();
}

void StreamSession::checkWatchdog()
{
    if (stopping_ || state_ != StreamState::RUNNING)
        return;
    
    std::chrono::steady_clock::time_point last_time;
    {
        std::lock_guard<std::mutex> lock(watchdog_mutex_);
        last_time = last_buffer_time_;
    }
    
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_time).count();
    
    if (elapsed > stall_timeout_sec_) {
        LOG_WARN("StreamSession", "[%s] Stream stalled - no buffer for %ld seconds", id_.c_str(), elapsed);
        setState(StreamState::STALL);
        handleError(StreamErrorType::STALL_TIMEOUT, "No buffer received for " + std::to_string(elapsed) + " seconds");
    }
}

void StreamSession::watchdogThreadFunc()
{
    LOG_INFO("StreamSession", "[%s] Watchdog thread started (timeout=%ds)", id_.c_str(), stall_timeout_sec_);
    
    while (watchdog_running_ && !stopping_) {
        // Check every second
        std::this_thread::sleep_for(std::chrono::seconds(1));
        
        if (watchdog_running_ && !stopping_) {
            checkWatchdog();
        }
    }
    
    LOG_INFO("StreamSession", "[%s] Watchdog thread stopped", id_.c_str());
}

GstPadProbeReturn StreamSession::onBufferProbe(GstPad* pad, GstPadProbeInfo* info, gpointer user_data)
{
    StreamSession* self = static_cast<StreamSession*>(user_data);
    if (self && !self->stopping_) {
        self->updateLastBufferTime();
    }
    return GST_PAD_PROBE_OK;
}

// ============================================================================
// Bus message handler - catches errors from pipeline
// ============================================================================

gboolean StreamSession::onBusMessage(GstBus* bus, GstMessage* msg, gpointer user_data)
{
    StreamSession* self = static_cast<StreamSession*>(user_data);
    if (!self || self->stopping_) return TRUE;

    // Helper to check if message source belongs to our stream
    auto isOurElement = [self](GstMessage* msg) -> bool {
        if (!self->pipeline_bin_) return false;
        
        GstObject* src = GST_MESSAGE_SRC(msg);
        if (!src) return false;
        
        // Check element name contains our stream ID
        const gchar* name = GST_OBJECT_NAME(src);
        if (name && strstr(name, self->id_.c_str())) {
            return true;
        }
        
        // Check hierarchy
        if (GST_IS_ELEMENT(src)) {
            GstElement* parent = GST_ELEMENT(src);
            while (parent) {
                if (parent == self->pipeline_bin_) {
                    return true;
                }
                parent = GST_ELEMENT_PARENT(parent);
            }
        }
        
        return false;
    };

    switch (GST_MESSAGE_TYPE(msg)) {
        case GST_MESSAGE_ERROR: {
            if (!isOurElement(msg)) break;
            
            GError* err = nullptr;
            gchar* debug = nullptr;
            gst_message_parse_error(msg, &err, &debug);
            
            const gchar* src_name = GST_MESSAGE_SRC(msg) ? GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)) : "unknown";
            LOG_ERROR("StreamSession", "[%s] Pipeline error from %s: %s", 
                      self->id_.c_str(), src_name, err->message);
            
            // Determine error type based on source
            StreamErrorType error_type = StreamErrorType::FATAL_ERROR;
            if (src_name) {
                if (strstr(src_name, "rtspsrc") ||
                    strstr(src_name, "urisourcebin") ||
                    strstr(src_name, "decodebin") ||
                    strstr(src_name, "rtsp") ||
                    strstr(src_name, "source")) {
                    error_type = StreamErrorType::SOURCE_ERROR;
                }
            }
            
            // Check error message for connection issues
            if (err->message) {
                if (strstr(err->message, "Could not open resource") ||
                    strstr(err->message, "Not found") ||
                    strstr(err->message, "connection") ||
                    strstr(err->message, "Connection") ||
                    strstr(err->message, "timed out") ||
                    strstr(err->message, "Could not read")) {
                    error_type = StreamErrorType::SOURCE_ERROR;
                }
            }
            
            std::string error_msg = err->message ? err->message : "Unknown error";
            g_error_free(err);
            g_free(debug);
            
            self->handleError(error_type, error_msg);
            break;
        }
        
        case GST_MESSAGE_WARNING: {
            if (!isOurElement(msg)) break;
            
            GError* err = nullptr;
            gchar* debug = nullptr;
            gst_message_parse_warning(msg, &err, &debug);
            
            const gchar* src_name = GST_MESSAGE_SRC(msg) ? GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)) : "unknown";
            LOG_WARN("StreamSession", "[%s] Warning from %s: %s", 
                     self->id_.c_str(), src_name, err->message);
            
            // Check for connection-related warnings that indicate stream loss
            bool connection_lost = false;
            if (err->message) {
                if (strstr(err->message, "closed") ||
                    strstr(err->message, "timed out") ||
                    strstr(err->message, "timeout") ||
                    strstr(err->message, "connection") ||
                    strstr(err->message, "Could not read")) {
                    connection_lost = true;
                }
            }
            
            g_error_free(err);
            g_free(debug);
            
            if (connection_lost) {
                self->handleError(StreamErrorType::SOURCE_ERROR, "Connection lost");
            }
            break;
        }
        
        case GST_MESSAGE_EOS: {
            if (!isOurElement(msg)) {
                // Also check if EOS is from main pipeline 
                GstObject* src = GST_MESSAGE_SRC(msg);
                if (src != GST_OBJECT(self->main_pipeline_)) break;
            }
            
            const gchar* src_name = GST_MESSAGE_SRC(msg) ? GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)) : "unknown";
            LOG_WARN("StreamSession", "[%s] EOS from %s", self->id_.c_str(), src_name);
            
            self->handleError(StreamErrorType::EOS, "End of stream");
            break;
        }
        
        case GST_MESSAGE_APPLICATION: {
            // Handle custom application messages (e.g., stream-eos from EOS probe)
            const GstStructure* s = gst_message_get_structure(msg);
            if (s) {
                const gchar* name = gst_structure_get_name(s);
                if (name && strcmp(name, "stream-eos") == 0) {
                    const gchar* sid = gst_structure_get_string(s, "stream-id");
                    if (sid && strcmp(sid, self->id_.c_str()) == 0) {
                        LOG_WARN("StreamSession", "[%s] Stream EOS detected", self->id_.c_str());
                        self->handleError(StreamErrorType::EOS, "Stream ended");
                    }
                }
            }
            break;
        }
        
        case GST_MESSAGE_STATE_CHANGED: {
            // Only log for our pipeline bin
            if (GST_MESSAGE_SRC(msg) == GST_OBJECT(self->pipeline_bin_)) {
                GstState old_state, new_state, pending_state;
                gst_message_parse_state_changed(msg, &old_state, &new_state, &pending_state);
                LOG_DEBUG("StreamSession", "[%s] State: %s -> %s", 
                          self->id_.c_str(),
                          gst_element_state_get_name(old_state),
                          gst_element_state_get_name(new_state));
            }
            break;
        }
        
        default:
            break;
    }
    
    return TRUE;
}
