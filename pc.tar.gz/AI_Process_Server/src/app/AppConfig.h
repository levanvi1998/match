#pragma once
#include <string>
#include <vector>

struct AppConfig
{
    // DeepStream Inference Configuration
    std::string inferConfigPath;
    int maxStreams;

    // S3 Configuration
    std::string s3Bucket;
    std::string s3Region;
    std::string s3Endpoint; // Optional: for S3-compatible storage (e.g., MinIO)
    std::string s3AccessKey;
    std::string s3SecretKey;
    std::string s3RoleArn; // Optional: for cross-account S3 access via assume role
    bool enableS3;

    // RTP output to mediasoup
    std::string rtpHost; // Mediasoup RTP endpoint host

    // HTTP Server Port
    int httpPort; // Port for HTTP API server

    // Metadata WebSocket to uWebSockets.js
    std::string metadataWSUrl; // WebSocket URL for metadata (e.g., "ws://localhost:9002/metadata")

    // Mediasoup server HTTP endpoint
    std::string mediasoupServerUrl; // HTTP URL for mediasoup API (e.g., "http://localhost:3000")

    // MediaMTX Configuration
    std::string mediamtxHost; // MediaMTX API host for checking stream availability
    int mediamtxPort;         // MediaMTX API port (default: 9997)

    // Recording Configuration
    std::string outputDir;
    int segmentDurationSec;
    bool autoRecord;  // Auto-upload to S3 when stream created (if false, use API to start/stop)
    bool deleteLocalIfNoUpload;  // Delete local files if S3 upload is disabled
    
    // Reconnection Configuration
    int maxReconnectAttempts;  // 0 = unlimited
    std::vector<int> backoffDelays;  // Backoff delays in seconds (e.g., [1,2,5,10,30])
    
    // Watchdog Configuration
    int stallTimeoutSec;  // Consider stream stalled after N seconds no buffer

    // Logging Configuration
    std::string logLevel;    // Application log level: fatal, error, warn, info, debug, verbose
    std::string gstLogLevel; // GStreamer log level: 0-9 or none, error, warning, fixme, info, debug, log, trace, memdump

    static AppConfig load(const std::string &path);
};
