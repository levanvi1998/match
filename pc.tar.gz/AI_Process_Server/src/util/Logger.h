#pragma once
#include <iostream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <mutex>
#include <string>
#include <cstdarg>
#include <cstring>
#include <unordered_map>
#include <chrono>

// Log levels (similar to DLT)
enum class LogLevel
{
    FATAL = 0,
    ERROR = 1,
    WARN = 2,
    INFO = 3,
    DEBUG = 4,
    VERBOSE = 5
};

class Logger
{
public:
    static Logger &getInstance()
    {
        static Logger instance;
        return instance;
    }

    void setLogLevel(LogLevel level)
    {
        std::lock_guard<std::mutex> lock(mutex_);
        currentLevel_ = level;
    }

    LogLevel getLogLevel() const
    {
        return currentLevel_;
    }

    void setRateLimiting(bool enabled, int windowSeconds = 5)
    {
        std::lock_guard<std::mutex> lock(mutex_);
        rateLimitEnabled_ = enabled;
        rateLimitWindowSeconds_ = windowSeconds;
    }

    void log(LogLevel level, const std::string &component, const char *format, ...)
    {
        if (level > currentLevel_)
            return;

        char buffer[4096];
        va_list args;
        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);

        std::lock_guard<std::mutex> lock(mutex_);

        if (rateLimitEnabled_)
        {
            std::string msgKey = component + ":" + std::string(buffer);
            auto now = std::chrono::steady_clock::now();

            auto it = lastLogTime_.find(msgKey);
            if (it != lastLogTime_.end())
            {
                auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - it->second).count();
                if (elapsed < rateLimitWindowSeconds_)
                {
                    // Skip this duplicate message
                    return;
                }
            }
            lastLogTime_[msgKey] = now;

            if (lastLogTime_.size() > 1000)
            {
                auto oldestAllowed = now - std::chrono::seconds(rateLimitWindowSeconds_ * 2);
                for (auto it = lastLogTime_.begin(); it != lastLogTime_.end();)
                {
                    if (it->second < oldestAllowed)
                    {
                        it = lastLogTime_.erase(it);
                    }
                    else
                    {
                        ++it;
                    }
                }
            }
        }

        auto now = std::time(nullptr);
        auto tm = *std::localtime(&now);

        std::ostringstream ss;
        ss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");

        const char *color = "";
        const char *reset = "\033[0m";
        const char *levelStr = "";

        switch (level)
        {
            case LogLevel::FATAL:
                color = "\033[1;35m"; // Magenta
                levelStr = "FATAL";
                break;
            case LogLevel::ERROR:
                color = "\033[1;31m"; // Red
                levelStr = "ERROR";
                break;
            case LogLevel::WARN:
                color = "\033[1;33m"; // Yellow
                levelStr = "WARN ";
                break;
            case LogLevel::INFO:
                color = "\033[1;32m"; // Green
                levelStr = "INFO ";
                break;
            case LogLevel::DEBUG:
                color = "\033[1;36m"; // Cyan
                levelStr = "DEBUG";
                break;
            case LogLevel::VERBOSE:
                color = "\033[1;37m"; // White
                levelStr = "VERBOSE";
                break;
        }

        std::cout << color << "[" << ss.str() << "] "
                  << "[" << levelStr << "] "
                  << "[" << component << "] "
                  << reset << buffer << std::endl;
    }

    void fatal(const std::string &component, const char *format, ...)
    {
        if (LogLevel::FATAL > currentLevel_)
            return;
        char buffer[4096];
        va_list args;
        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);
        log(LogLevel::FATAL, component, "%s", buffer);
    }

    void error(const std::string &component, const char *format, ...)
    {
        if (LogLevel::ERROR > currentLevel_)
            return;
        char buffer[4096];
        va_list args;
        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);
        log(LogLevel::ERROR, component, "%s", buffer);
    }

    void warn(const std::string &component, const char *format, ...)
    {
        if (LogLevel::WARN > currentLevel_)
            return;
        char buffer[4096];
        va_list args;
        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);
        log(LogLevel::WARN, component, "%s", buffer);
    }

    void info(const std::string &component, const char *format, ...)
    {
        if (LogLevel::INFO > currentLevel_)
            return;
        char buffer[4096];
        va_list args;
        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);
        log(LogLevel::INFO, component, "%s", buffer);
    }

    void debug(const std::string &component, const char *format, ...)
    {
        if (LogLevel::DEBUG > currentLevel_)
            return;
        char buffer[4096];
        va_list args;
        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);
        log(LogLevel::DEBUG, component, "%s", buffer);
    }

    void verbose(const std::string &component, const char *format, ...)
    {
        if (LogLevel::VERBOSE > currentLevel_)
            return;
        char buffer[4096];
        va_list args;
        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);
        log(LogLevel::VERBOSE, component, "%s", buffer);
    }

private:
    Logger() : currentLevel_(LogLevel::INFO), rateLimitEnabled_(true), rateLimitWindowSeconds_(5) {}
    ~Logger() = default;
    Logger(const Logger &) = delete;
    Logger &operator=(const Logger &) = delete;

    LogLevel currentLevel_;
    std::mutex mutex_;
    bool rateLimitEnabled_;
    int rateLimitWindowSeconds_;
    std::unordered_map<std::string, std::chrono::steady_clock::time_point> lastLogTime_;
};

// Convenience macros - support both string and printf-style
#define LOG_FATAL(component, ...) Logger::getInstance().fatal(component, __VA_ARGS__)
#define LOG_ERROR(component, ...) Logger::getInstance().error(component, __VA_ARGS__)
#define LOG_WARN(component, ...) Logger::getInstance().warn(component, __VA_ARGS__)
#define LOG_INFO(component, ...) Logger::getInstance().info(component, __VA_ARGS__)
#define LOG_DEBUG(component, ...) Logger::getInstance().debug(component, __VA_ARGS__)
#define LOG_VERBOSE(component, ...) Logger::getInstance().verbose(component, __VA_ARGS__)

// String to LogLevel converter
inline LogLevel logLevelFromString(const std::string &level)
{
    if (level == "fatal" || level == "FATAL")
        return LogLevel::FATAL;
    if (level == "error" || level == "ERROR")
        return LogLevel::ERROR;
    if (level == "warn" || level == "WARN")
        return LogLevel::WARN;
    if (level == "info" || level == "INFO")
        return LogLevel::INFO;
    if (level == "debug" || level == "DEBUG")
        return LogLevel::DEBUG;
    if (level == "verbose" || level == "VERBOSE")
        return LogLevel::VERBOSE;
    return LogLevel::INFO; // default
}
