#include "UriUtils.h"
#include <regex>
#include <algorithm>

// Default ports for protocols
static const int RTMP_DEFAULT_PORT = 1935;
static const int RTSP_DEFAULT_PORT = 554;
static const int RTSP_ALT_PORT = 8554;

int getDefaultPort(const std::string& protocol) {
    std::string proto = protocol;
    std::transform(proto.begin(), proto.end(), proto.begin(), ::tolower);
    
    if (proto == "rtmp") {
        return RTMP_DEFAULT_PORT;
    } else if (proto == "rtsp" || proto == "rtsps") {
        return RTSP_DEFAULT_PORT;
    }
    return 0;
}

bool isValidPortForProtocol(const std::string& protocol, int port) {
    std::string proto = protocol;
    std::transform(proto.begin(), proto.end(), proto.begin(), ::tolower);
    
    if (proto == "rtmp") {
        // RTMP typically uses 1935, but can use other ports
        // We'll only allow 1935 for strict validation
        return port == RTMP_DEFAULT_PORT;
    } else if (proto == "rtsp" || proto == "rtsps") {
        // RTSP uses 554 (default) or 8554 (common alternative)
        return port == RTSP_DEFAULT_PORT || port == RTSP_ALT_PORT;
    }
    
    return false;
}

std::optional<UriInfo> parseUri(const std::string& uri) {
    if (uri.empty()) {
        return std::nullopt;
    }
    
    // URI format: protocol://host[:port][/path]
    // Examples:
    //   rtmp://192.168.1.100:1935/live/video1
    //   rtsp://192.168.1.100/camera1
    //   rtsp://192.168.1.100:8554/live/stream
    
    // Regex to parse URI: (protocol)://(host)[:port][/path]
    std::regex uri_regex(
        R"(^([a-zA-Z][a-zA-Z0-9+.-]*)://)"  // protocol://
        R"(([^/:]+))"                        // host (no : or /)
        R"((?::(\d+))?)"                     // optional :port
        R"((/.*)?$)"                         // optional /path
    );
    
    std::smatch match;
    if (!std::regex_match(uri, match, uri_regex)) {
        return std::nullopt;
    }
    
    UriInfo info;
    info.originalUri = uri;
    info.protocol = match[1].str();
    info.host = match[2].str();
    
    // Parse port or use default
    if (match[3].matched && !match[3].str().empty()) {
        try {
            info.port = std::stoi(match[3].str());
        } catch (...) {
            return std::nullopt;
        }
    } else {
        info.port = getDefaultPort(info.protocol);
        if (info.port == 0) {
            // Unknown protocol, can't determine default port
            return std::nullopt;
        }
    }
    
    // Path (optional)
    if (match[4].matched) {
        info.path = match[4].str();
    }
    
    // Convert protocol to lowercase for consistency
    std::transform(info.protocol.begin(), info.protocol.end(), info.protocol.begin(), ::tolower);
    
    return info;
}

UriValidationResult validateStreamUri(const std::string& uri) {
    if (uri.empty()) {
        return UriValidationResult::fail("URI is empty");
    }
    
    auto parsed = parseUri(uri);
    if (!parsed) {
        return UriValidationResult::fail("Invalid URI format. Expected: protocol://host[:port][/path]");
    }
    
    const UriInfo& info = *parsed;
    
    // Only allow rtmp and rtsp protocols
    if (info.protocol != "rtmp" && info.protocol != "rtsp" && info.protocol != "rtsps") {
        return UriValidationResult::fail(
            "Unsupported protocol '" + info.protocol + "'. Only rtmp and rtsp are allowed"
        );
    }
    
    // Validate port matches protocol
    if (!isValidPortForProtocol(info.protocol, info.port)) {
        std::string expected_ports;
        if (info.protocol == "rtmp") {
            expected_ports = "1935";
        } else {
            expected_ports = "554 or 8554";
        }
        return UriValidationResult::fail(
            "Invalid port " + std::to_string(info.port) + " for protocol " + info.protocol + 
            ". Expected port: " + expected_ports
        );
    }
    
    // Validate host is not empty
    if (info.host.empty()) {
        return UriValidationResult::fail("Host is empty");
    }
    
    // Path validation for streaming - should have a path
    if (info.path.empty() || info.path == "/") {
        return UriValidationResult::fail("Stream path is required (e.g., /live/video1)");
    }
    
    return UriValidationResult::ok(info);
}
