#pragma once
#include <string>

/**
 * MediaMTX path check result
 */
struct MediaMTXPathResult {
    bool exists;         // True if path exists and is ready
    bool ready;          // True if stream is ready (has active source)
    std::string errorMsg;   // Error message if check failed
    std::string source;  // Source type (e.g., "rtmpConn")
    
    static MediaMTXPathResult success(bool ready, const std::string& source = "") {
        return {true, ready, "", source};
    }
    
    static MediaMTXPathResult notFound(const std::string& path) {
        return {false, false, "Path '" + path + "' not found in MediaMTX", ""};
    }
    
    static MediaMTXPathResult fail(const std::string& msg) {
        return {false, false, msg, ""};
    }
};

/**
 * MediaMTX API client for checking stream availability
 */
class MediaMTXChecker {
public:
    MediaMTXChecker(const std::string& host, int port);
    ~MediaMTXChecker() = default;
    
    /**
     * Check if a path exists in MediaMTX
     * Uses the /v3/paths/get/{path} API endpoint
     * 
     * @param path The stream path to check (e.g., "live/video1")
     * @return MediaMTXPathResult with exists=true if path is available
     */
    MediaMTXPathResult checkPath(const std::string& path);
    
    /**
     * Extract path from a stream URI
     * E.g., rtmp://host:1935/live/video1 -> live/video1
     * 
     * @param uri The full stream URI
     * @return The path component without leading slash
     */
    static std::string extractPathFromUri(const std::string& uri);
    
private:
    std::string host_;
    int port_;
};
