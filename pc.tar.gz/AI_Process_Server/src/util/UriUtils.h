#pragma once
#include <string>
#include <optional>

/**
 * UriInfo - Parsed URI components
 */
struct UriInfo {
    std::string protocol;  // rtmp, rtsp, etc.
    std::string host;      // IP or hostname
    int port;              // Port number
    std::string path;      // Path after host:port (e.g., /live/video1)
    
    // Full original URI
    std::string originalUri;
    
    // Check if the URI is valid
    bool isValid() const { return !protocol.empty() && !host.empty() && port > 0; }
};

/**
 * UriValidationResult - Result of URI validation
 */
struct UriValidationResult {
    bool valid;
    std::string error;
    UriInfo info;
    
    static UriValidationResult ok(const UriInfo& info) {
        return {true, "", info};
    }
    
    static UriValidationResult fail(const std::string& error) {
        return {false, error, {}};
    }
};

/**
 * Parse a URI into its components
 * @param uri The URI to parse (e.g., rtmp://192.168.1.100:1935/live/video1)
 * @return Optional UriInfo, empty if parsing failed
 */
std::optional<UriInfo> parseUri(const std::string& uri);

/**
 * Validate a stream URI for RTMP/RTSP protocols
 * Checks:
 * - Protocol is rtmp or rtsp
 * - Port matches expected protocol (rtmp=1935, rtsp=8554/554)
 * - URI is well-formed
 * 
 * @param uri The URI to validate
 * @return UriValidationResult with valid=true or error message
 */
UriValidationResult validateStreamUri(const std::string& uri);

/**
 * Get default port for a protocol
 * @param protocol The protocol (rtmp, rtsp)
 * @return Default port number, or 0 if unknown protocol
 */
int getDefaultPort(const std::string& protocol);

/**
 * Check if a port is valid for a given protocol
 * @param protocol The protocol (rtmp, rtsp)
 * @param port The port number
 * @return true if port is valid for the protocol
 */
bool isValidPortForProtocol(const std::string& protocol, int port);
