#include "MediaMTXChecker.h"
#include "Logger.h"
#include "UriUtils.h"
#include <httplib.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

MediaMTXChecker::MediaMTXChecker(const std::string& host, int port)
    : host_(host), port_(port)
{
    LOG_DEBUG("MediaMTXChecker", "Initialized with endpoint %s:%d", host_.c_str(), port_);
}

std::string MediaMTXChecker::extractPathFromUri(const std::string& uri) {
    auto parsed = parseUri(uri);
    if (!parsed || parsed->path.empty()) {
        return "";
    }
    
    // Remove leading slash
    std::string path = parsed->path;
    if (!path.empty() && path[0] == '/') {
        path = path.substr(1);
    }
    
    return path;
}

MediaMTXPathResult MediaMTXChecker::checkPath(const std::string& path) {
    if (path.empty()) {
        return MediaMTXPathResult::fail("Empty path provided");
    }
    
    try {
        httplib::Client cli(host_, port_);
        cli.set_connection_timeout(2, 0);  // 2 second timeout
        cli.set_read_timeout(2, 0);
        cli.set_write_timeout(2, 0);
        
        // MediaMTX API: GET /v3/paths/get/{path}
        std::string endpoint = "/v3/paths/get/" + path;
        
        LOG_DEBUG("MediaMTXChecker", "Checking path: GET %s:%d%s", host_.c_str(), port_, endpoint.c_str());
        
        auto res = cli.Get(endpoint.c_str());
        
        if (!res) {
            std::string error_msg = "Failed to connect to MediaMTX at " + host_ + ":" + std::to_string(port_);
            LOG_WARN("MediaMTXChecker", "%s", error_msg.c_str());
            return MediaMTXPathResult::fail(error_msg);
        }
        
        if (res->status == 200) {
            try {
                auto response = json::parse(res->body);
                
                // Check if path is ready (has active source)
                bool ready = response.value("ready", false);
                std::string source_type = "";
                
                if (response.contains("source") && response["source"].is_object()) {
                    source_type = response["source"].value("type", "");
                }
                
                LOG_DEBUG("MediaMTXChecker", "Path '%s' found: ready=%s, source=%s", 
                         path.c_str(), ready ? "true" : "false", source_type.c_str());
                
                return MediaMTXPathResult::success(ready, source_type);
            }
            catch (std::exception& e) {
                LOG_WARN("MediaMTXChecker", "Failed to parse MediaMTX response: %s", e.what());
                // Path exists but couldn't parse response - assume not ready
                return MediaMTXPathResult::success(false);
            }
        }
        else {
            // Path not found or error
            LOG_DEBUG("MediaMTXChecker", "Path '%s' not found (status=%d)", path.c_str(), res->status);
            return MediaMTXPathResult::notFound(path);
        }
    }
    catch (std::exception& e) {
        std::string error_msg = std::string("MediaMTX check failed: ") + e.what();
        LOG_WARN("MediaMTXChecker", "%s", error_msg.c_str());
        return MediaMTXPathResult::fail(error_msg);
    }
}
